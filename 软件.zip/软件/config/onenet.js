// OneNET 平台配置
const ONE_NET_CONFIG = {
	// HTTP接入地址
	HTTP_BASE_URL: 'https://open.iot.10086.cn/studio/http',
	
	// 产品ID（在OneNET平台产品详情页获取）
	PRODUCT_ID: 'fQ88v8SIm9',
	
	// 设备名称（在OneNET平台设备详情页获取）
	DEVICE_NAME: 'HealthDevice001',
	
	// 设备密钥（在OneNET平台设备详情页获取）
	DEVICE_SECRET: 'TWVvTTRycmhQdVl0RlpjS2JrdXBjVUZpSzRweVRWemI=',
	
	// Token版本号
	TOKEN_VERSION: '2018-10-31',
	
	// 签名方法：hmacmd5、hmacsha1、hmacsha256
	SIGNATURE_METHOD: 'sha1',
	
	// Token有效期（秒），默认7天
	TOKEN_EXPIRE_TIME: 7 * 24 * 60 * 60,
	
	// 预生成的 Token（100年有效期）
	// 生成时间：2025-01-15
	// 过期时间：2125-01-15
	// 生成工具：OneNET 官方 Token 工具
	PRE_GENERATED_TOKEN: 'version=2018-10-31&res=products%2FfQ88v8SIm9%2Fdevices%2FHealthDevice001&et=4765363200&method=sha1&sign=i6BXg0Ckqi7VRl%2FC8d5MrIC61uU%3D'
}

// 数据流ID定义
const DATA_STREAMS = {
	HEART_RATE: 'heart_rate',      // 心率
	BLOOD_OXYGEN: 'blood_oxygen',  // 血氧
	STEPS: 'steps',                // 步数
	DISTANCE: 'distance',          // 距离
	DEVICE_STATUS: 'device_status' // 设备状态
}

module.exports = {
	ONE_NET_CONFIG,
	DATA_STREAMS
}
