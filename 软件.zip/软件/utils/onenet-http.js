/**
 * OneNET HTTP 接入工具类
 * 用于历史数据上报到 OneNET 云平台
 */

const { ONE_NET_CONFIG, DATA_STREAMS } = require('../config/onenet.js')

class OneNetHttpClient {
	constructor() {
		this.baseUrl = ONE_NET_CONFIG.HTTP_BASE_URL
		this.productId = ONE_NET_CONFIG.PRODUCT_ID
		this.deviceName = ONE_NET_CONFIG.DEVICE_NAME
		this.deviceSecret = ONE_NET_CONFIG.DEVICE_SECRET
	}

	/**
	 * 生成 OneNET Token
	 * @param {number} expireTime - 过期时间戳（秒）
	 * @returns {string} token字符串
	 */
	generateToken(expireTime) {
		const version = ONE_NET_CONFIG.TOKEN_VERSION
		const method = ONE_NET_CONFIG.SIGNATURE_METHOD
		const res = `products/${this.productId}/devices/${this.deviceName}`
		
		// 构造签名字符串：et\nmethod\nres\nversion
		const stringForSignature = `${expireTime}\n${method}\n${res}\n${version}`
		
		// 使用 HMAC-SHA1 签名
		const signature = this.hmacSha1(stringForSignature, this.deviceSecret)
		
		// 构造 token 参数
		const params = {
			version: version,
			res: res,
			et: expireTime.toString(),
			method: method,
			sign: signature
		}
		
		// URL 编码并拼接
		const tokenParts = []
		for (const [key, value] of Object.entries(params)) {
			tokenParts.push(`${key}=${this.urlEncode(value)}`)
		}
		
		return tokenParts.join('&')
	}

	/**
	 * HMAC-SHA1 签名
	 * @param {string} message - 消息
	 * @param {string} secret - 密钥
	 * @returns {string} base64编码的签名
	 */
	hmacSha1(message, secret) {
		// 先对 secret 进行 base64 解码
		const key = this.base64Decode(secret)
		
		// 使用 CryptoJS 或自行实现 HMAC-SHA1
		// 这里使用简单的实现，实际项目中建议使用 crypto-js 库
		return this.simpleHmacSha1(message, key)
	}

	/**
	 * 简化的 HMAC-SHA1 实现（用于小程序环境）
	 * 注意：实际项目中建议使用 crypto-js 库
	 */
	simpleHmacSha1(message, key) {
		// 由于 uni-app 环境限制，这里提供一个简化版本
		// 实际使用时，建议引入 crypto-js 库
		// 或者使用后端服务生成 token
		
		// 临时方案：返回一个占位符，实际项目中需要替换
		console.warn('请使用后端服务生成 Token，或引入 crypto-js 库')
		return 'placeholder_token'
	}

	/**
	 * Base64 解码
	 */
	base64Decode(str) {
		try {
			// 小程序环境使用 wx.arrayBufferToBase64 的反向操作
			const buffer = uni.base64ToArrayBuffer(str)
			return String.fromCharCode.apply(null, new Uint8Array(buffer))
		} catch (e) {
			console.error('Base64解码失败:', e)
			return str
		}
	}

	/**
	 * URL 编码
	 */
	urlEncode(str) {
		return encodeURIComponent(str)
			.replace(/%20/g, '+')
			.replace(/%2F/g, '%2F')
			.replace(/%3D/g, '%3D')
	}

	/**
	 * 获取当前 Token
	 */
	getCurrentToken() {
		const expireTime = Math.floor(Date.now() / 1000) + ONE_NET_CONFIG.TOKEN_EXPIRE_TIME
		return this.generateToken(expireTime)
	}

	/**
	 * 上报设备属性（单条数据）
	 * @param {Object} data - 数据对象
	 * @param {number} data.heart_rate - 心率
	 * @param {number} data.blood_oxygen - 血氧
	 * @param {number} data.steps - 步数
	 * @param {number} data.distance - 距离
	 * @returns {Promise}
	 */
	async uploadProperty(data) {
		const token = this.getCurrentToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/property/post`
		
		// 构造 OneJSON 格式数据
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: {}
		}
		
		// 添加属性数据
		if (data.heart_rate !== undefined) {
			oneJson.params.heart_rate = {
				value: data.heart_rate,
				time: Date.now()
			}
		}
		
		if (data.blood_oxygen !== undefined) {
			oneJson.params.blood_oxygen = {
				value: data.blood_oxygen,
				time: Date.now()
			}
		}
		
		if (data.steps !== undefined) {
			oneJson.params.steps = {
				value: data.steps,
				time: Date.now()
			}
		}
		
		if (data.distance !== undefined) {
			oneJson.params.distance = {
				value: data.distance,
				time: Date.now()
			}
		}
		
		return this.httpPost('/device/thing/property/post', oneJson, token, topic)
	}

	/**
	 * 批量上报数据
	 * @param {Array} dataList - 数据列表
	 * @returns {Promise}
	 */
	async uploadBatch(dataList) {
		const token = this.getCurrentToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/pack/post`
		
		// 构造批量数据
		const params = {}
		
		dataList.forEach((data, index) => {
			const timestamp = new Date(data.datetime || data.saveTime).getTime() || Date.now()
			
			if (data.type === 'normal') {
				// 普通记录：心率、血氧
				if (!params.heart_rate) params.heart_rate = []
				if (!params.blood_oxygen) params.blood_oxygen = []
				
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
				
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			} else if (data.type === 'running') {
				// 运动记录：步数、距离、心率、血氧
				if (!params.steps) params.steps = []
				if (!params.distance) params.distance = []
				if (!params.heart_rate) params.heart_rate = []
				if (!params.blood_oxygen) params.blood_oxygen = []
				
				params.steps.push({
					value: data.steps,
					time: timestamp
				})
				
				params.distance.push({
					value: data.distance,
					time: timestamp
				})
				
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
				
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			}
		})
		
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: params
		}
		
		return this.httpPost('/device/thing/pack/post', oneJson, token, topic)
	}

	/**
	 * 上报历史数据
	 * @param {Array} historyData - 历史数据列表
	 * @returns {Promise}
	 */
	async uploadHistory(historyData) {
		const token = this.getCurrentToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/history/post`
		
		// 构造历史数据格式
		const params = {}
		
		historyData.forEach((data) => {
			const timestamp = new Date(data.datetime || data.saveTime).getTime() || Date.now()
			
			// 根据数据类型组织数据
			if (data.hr !== undefined) {
				if (!params.heart_rate) params.heart_rate = []
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
			}
			
			if (data.spo2 !== undefined) {
				if (!params.blood_oxygen) params.blood_oxygen = []
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			}
			
			if (data.steps !== undefined) {
				if (!params.steps) params.steps = []
				params.steps.push({
					value: data.steps,
					time: timestamp
				})
			}
			
			if (data.distance !== undefined) {
				if (!params.distance) params.distance = []
				params.distance.push({
					value: data.distance,
					time: timestamp
				})
			}
		})
		
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: params
		}
		
		return this.httpPost('/device/thing/history/post', oneJson, token, topic)
	}

	/**
	 * HTTP POST 请求
	 * @param {string} url - 请求路径
	 * @param {Object} data - 请求数据
	 * @param {string} token - 鉴权token
	 * @param {string} topic - 主题
	 * @returns {Promise}
	 */
	httpPost(url, data, token, topic) {
		return new Promise((resolve, reject) => {
			const fullUrl = `${this.baseUrl}${url}?topic=${encodeURIComponent(topic)}&protocol=HTTP`
			
			uni.request({
				url: fullUrl,
				method: 'POST',
				header: {
					'Content-Type': 'application/json',
					'token': token
				},
				data: data,
				success: (res) => {
					if (res.statusCode === 200 && res.data && res.data.code === 0) {
						resolve({
							success: true,
							data: res.data
						})
					} else {
						reject({
							success: false,
							error: res.data || res
						})
					}
				},
				fail: (err) => {
					reject({
						success: false,
						error: err
					})
				}
			})
		})
	}

	/**
	 * 生成消息ID
	 */
	generateMessageId() {
		return Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
	}
}

// 导出单例
const oneNetClient = new OneNetHttpClient()

module.exports = {
	OneNetHttpClient,
	oneNetClient,
	DATA_STREAMS
}
