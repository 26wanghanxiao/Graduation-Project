/**
 * OneNET Token 生成工具
 * 
 * 使用方法：
 * 1. 在 Node.js 环境中运行：node token-generator.js
 * 2. 或在浏览器控制台中使用（需要 crypto-js 库）
 * 
 * 注意：由于 uni-app 小程序环境不支持 crypto 模块，
 * 建议：
 * - 方案1：使用后端服务生成 Token
 * - 方案2：在 Node.js 环境生成 Token 后硬编码到配置中
 * - 方案3：使用 OneNET 官方提供的 Token 生成工具
 */

// 引入 crypto 模块（Node.js 环境）
const crypto = require('crypto')

/**
 * Base64 解码
 * @param {string} str - base64字符串
 * @returns {Buffer}
 */
function base64Decode(str) {
	return Buffer.from(str, 'base64')
}

/**
 * URL 编码（保留特定字符不编码）
 * @param {string} str - 要编码的字符串
 * @returns {string}
 */
function urlEncode(str) {
	return encodeURIComponent(str)
		.replace(/%20/g, '+')
		.replace(/%2F/g, '%2F')
		.replace(/%3D/g, '%3D')
		.replace(/%26/g, '%26')
}

/**
 * 生成 OneNET Token
 * @param {Object} options - 配置选项
 * @param {string} options.productId - 产品ID
 * @param {string} options.deviceName - 设备名称
 * @param {string} options.deviceSecret - 设备密钥
 * @param {number} options.expireTime - 过期时间戳（秒）
 * @param {string} options.version - Token版本，默认 '2018-10-31'
 * @param {string} options.method - 签名方法，默认 'sha1'
 * @returns {string} 生成的Token
 */
function generateToken(options) {
	const {
		productId,
		deviceName,
		deviceSecret,
		expireTime,
		version = '2018-10-31',
		method = 'sha1'
	} = options

	// 构造资源字符串
	const res = `products/${productId}/devices/${deviceName}`

	// 构造签名字符串（按参数名排序：et, method, res, version）
	const stringForSignature = `${expireTime}\n${method}\n${res}\n${version}`

	console.log('签名字符串:', stringForSignature)

	// 对密钥进行 base64 解码
	const key = base64Decode(deviceSecret)

	// 使用 HMAC-SHA1 签名
	const hmac = crypto.createHmac(method, key)
	hmac.update(stringForSignature)
	const signature = hmac.digest('base64')

	console.log('签名结果:', signature)

	// 构造 token 参数
	const params = {
		version: version,
		res: res,
		et: expireTime.toString(),
		method: method,
		sign: signature
	}

	// URL 编码并拼接
	const tokenParts = []
	for (const [key, value] of Object.entries(params)) {
		tokenParts.push(`${key}=${urlEncode(value)}`)
	}

	return tokenParts.join('&')
}

/**
 * 生成长期有效的 Token（100年）
 * @param {Object} config - 配置对象
 * @returns {string} Token
 */
function generateLongTermToken(config) {
	const expireTime = Math.floor(Date.now() / 1000) + 100 * 365 * 24 * 60 * 60 // 100年后
	return generateToken({
		...config,
		expireTime
	})
}

// ==================== 使用示例 ====================

// 配置信息（请替换为你的实际配置）
const config = {
	productId: 'fQ88v8SIm9',                       // 产品ID
	deviceName: 'HealthDevice001',                 // 设备名称
	deviceSecret: 'TWVvTTRycmhQdVl0RlpjS2JrdXBjVUZpSzRweVRWemI=' // 设备密钥
}

// 生成 Token
console.log('\n========== OneNET Token 生成工具 ==========\n')

// 示例1：生成 7 天有效期的 Token
const expireTime7Days = Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60
const token7Days = generateToken({
	...config,
	expireTime: expireTime7Days
})
console.log('7天有效期 Token:')
console.log(token7Days)
console.log('\n')

// 示例2：生成 30 天有效期的 Token
const expireTime30Days = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60
const token30Days = generateToken({
	...config,
	expireTime: expireTime30Days
})
console.log('30天有效期 Token:')
console.log(token30Days)
console.log('\n')

// 示例3：生成 100 年有效期的 Token（长期使用）
const longTermToken = generateLongTermToken(config)
console.log('100年有效期 Token（长期使用）:')
console.log(longTermToken)
console.log('\n')

// 导出函数
module.exports = {
	generateToken,
	generateLongTermToken,
	urlEncode,
	base64Decode
}

// 如果在命令行直接运行
if (require.main === module) {
	console.log('提示：请将 config 中的参数替换为你的实际配置后再运行')
	console.log('使用方法：')
	console.log('1. 修改本文件中的 config 对象')
	console.log('2. 运行：node token-generator.js')
	console.log('3. 将生成的 Token 复制到 onenet.js 配置文件中使用')
}
