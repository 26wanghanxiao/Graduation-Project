/**
 * OneNET HTTP 接入工具类（简化版）
 * 
 * 使用预生成 Token 方案，适合前端/小程序环境
 * 
 * 使用步骤：
 * 1. 在 Node.js 环境运行 token-generator.js 生成 Token
 * 2. 将生成的 Token 复制到 config/onenet.js 中
 * 3. 使用本工具类进行数据上报
 */

const { ONE_NET_CONFIG, DATA_STREAMS } = require('../config/onenet.js')

class OneNetSimpleClient {
	constructor() {
		this.baseUrl = ONE_NET_CONFIG.HTTP_BASE_URL
		this.productId = ONE_NET_CONFIG.PRODUCT_ID
		this.deviceName = ONE_NET_CONFIG.DEVICE_NAME
	}

	/**
	 * 获取 Token（从配置文件或动态获取）
	 * 如果使用预生成 Token，直接返回配置中的 token
	 */
	getToken() {
		// 如果配置了预生成 Token，直接使用
		if (ONE_NET_CONFIG.PRE_GENERATED_TOKEN) {
			return ONE_NET_CONFIG.PRE_GENERATED_TOKEN
		}
		
		// 否则抛出错误，提示用户生成 Token
		throw new Error('请先在 config/onenet.js 中配置 PRE_GENERATED_TOKEN，或使用 token-generator.js 生成')
	}

	/**
	 * 上报设备属性（单条数据）
	 * @param {Object} data - 数据对象
	 * @returns {Promise}
	 */
	async uploadProperty(data) {
		const token = this.getToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/property/post`
		
		// 构造 OneJSON 格式数据
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: {}
		}
		
		// 添加属性数据
		if (data.heart_rate !== undefined) {
			oneJson.params.heart_rate = {
				value: data.heart_rate,
				time: Date.now()
			}
		}
		
		if (data.blood_oxygen !== undefined) {
			oneJson.params.blood_oxygen = {
				value: data.blood_oxygen,
				time: Date.now()
			}
		}
		
		if (data.steps !== undefined) {
			oneJson.params.steps = {
				value: data.steps,
				time: Date.now()
			}
		}
		
		if (data.distance !== undefined) {
			oneJson.params.distance = {
				value: data.distance,
				time: Date.now()
			}
		}
		
		return this.httpPost('/device/thing/property/post', oneJson, token, topic)
	}

	/**
	 * 批量上报数据
	 * @param {Array} dataList - 数据列表
	 * @returns {Promise}
	 */
	async uploadBatch(dataList) {
		const token = this.getToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/pack/post`
		
		// 构造批量数据
		const params = {}
		
		dataList.forEach((data, index) => {
			const timestamp = new Date(data.datetime || data.saveTime).getTime() || Date.now()
			
			if (data.type === 'normal') {
				// 普通记录：心率、血氧
				if (!params.heart_rate) params.heart_rate = []
				if (!params.blood_oxygen) params.blood_oxygen = []
				
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
				
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			} else if (data.type === 'running') {
				// 运动记录：步数、距离、心率、血氧
				if (!params.steps) params.steps = []
				if (!params.distance) params.distance = []
				if (!params.heart_rate) params.heart_rate = []
				if (!params.blood_oxygen) params.blood_oxygen = []
				
				params.steps.push({
					value: data.steps,
					time: timestamp
				})
				
				params.distance.push({
					value: data.distance,
					time: timestamp
				})
				
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
				
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			}
		})
		
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: params
		}
		
		console.log('上报数据:', JSON.stringify(oneJson, null, 2))
		
		return this.httpPost('/device/thing/pack/post', oneJson, token, topic)
	}

	/**
	 * 上报历史数据
	 * @param {Array} historyData - 历史数据列表
	 * @returns {Promise}
	 */
	async uploadHistory(historyData) {
		const token = this.getToken()
		const topic = `$sys/${this.productId}/${this.deviceName}/thing/history/post`
		
		// 构造历史数据格式
		const params = {}
		
		historyData.forEach((data) => {
			const timestamp = new Date(data.datetime || data.saveTime).getTime() || Date.now()
			
			if (data.hr !== undefined) {
				if (!params.heart_rate) params.heart_rate = []
				params.heart_rate.push({
					value: data.hr,
					time: timestamp
				})
			}
			
			if (data.spo2 !== undefined) {
				if (!params.blood_oxygen) params.blood_oxygen = []
				params.blood_oxygen.push({
					value: data.spo2,
					time: timestamp
				})
			}
			
			if (data.steps !== undefined) {
				if (!params.steps) params.steps = []
				params.steps.push({
					value: data.steps,
					time: timestamp
				})
			}
			
			if (data.distance !== undefined) {
				if (!params.distance) params.distance = []
				params.distance.push({
					value: data.distance,
					time: timestamp
				})
			}
		})
		
		const oneJson = {
			id: this.generateMessageId(),
			version: '1.0',
			params: params
		}
		
		return this.httpPost('/device/thing/history/post', oneJson, token, topic)
	}

	/**
	 * HTTP POST 请求
	 * @param {string} url - 请求路径
	 * @param {Object} data - 请求数据
	 * @param {string} token - 鉴权token
	 * @param {string} topic - 主题
	 * @returns {Promise}
	 */
	httpPost(url, data, token, topic) {
		return new Promise((resolve, reject) => {
			const fullUrl = `${this.baseUrl}${url}?topic=${encodeURIComponent(topic)}&protocol=HTTP`
			
			console.log('请求URL:', fullUrl)
			console.log('Token:', token.substring(0, 50) + '...')
			
			uni.request({
				url: fullUrl,
				method: 'POST',
				header: {
					'Content-Type': 'application/json',
					'token': token
				},
				data: data,
				success: (res) => {
					console.log('响应:', res)
					if (res.statusCode === 200 && res.data && res.data.code === 0) {
						resolve({
							success: true,
							data: res.data
						})
					} else {
						reject({
							success: false,
							error: res.data || res
						})
					}
				},
				fail: (err) => {
					console.error('请求失败:', err)
					reject({
						success: false,
						error: err
					})
				}
			})
		})
	}

	/**
	 * 生成消息ID
	 */
	generateMessageId() {
		return Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
	}
}

// 导出单例
const oneNetClient = new OneNetSimpleClient()

module.exports = {
	OneNetSimpleClient,
	oneNetClient,
	DATA_STREAMS
}
