/**
 * OneNET 配置检查工具
 * 用于验证配置是否正确，测试 Token 是否有效
 */

const { ONE_NET_CONFIG } = require('../config/onenet.js')

class OneNetConfigChecker {
	constructor() {
		this.config = ONE_NET_CONFIG
	}

	/**
	 * 检查配置是否完整
	 */
	checkConfig() {
		const results = {
			isValid: true,
			errors: [],
			warnings: []
		}

		console.log('========== OneNET 配置检查 ==========\n')

		// 检查产品ID
		if (!this.config.PRODUCT_ID || this.config.PRODUCT_ID === 'your_product_id_here') {
			results.errors.push('❌ PRODUCT_ID 未配置，请填写你的产品ID')
			results.isValid = false
		} else {
			console.log('✅ PRODUCT_ID:', this.config.PRODUCT_ID)
		}

		// 检查设备名称
		if (!this.config.DEVICE_NAME || this.config.DEVICE_NAME === 'your_device_name_here') {
			results.errors.push('❌ DEVICE_NAME 未配置，请填写你的设备名称')
			results.isValid = false
		} else {
			console.log('✅ DEVICE_NAME:', this.config.DEVICE_NAME)
		}

		// 检查设备密钥
		if (!this.config.DEVICE_SECRET || this.config.DEVICE_SECRET === 'your_device_secret_here') {
			results.warnings.push('⚠️ DEVICE_SECRET 未配置（如使用预生成 Token，此项可选）')
		} else {
			console.log('✅ DEVICE_SECRET:', this.maskString(this.config.DEVICE_SECRET))
		}

		// 检查预生成 Token
		if (!this.config.PRE_GENERATED_TOKEN) {
			results.errors.push('❌ PRE_GENERATED_TOKEN 未配置，请先运行 token-generator.js 生成 Token')
			results.isValid = false
		} else {
			console.log('✅ PRE_GENERATED_TOKEN:', this.maskString(this.config.PRE_GENERATED_TOKEN))
			
			// 解析 Token 检查有效期
			const tokenInfo = this.parseToken(this.config.PRE_GENERATED_TOKEN)
			if (tokenInfo) {
				console.log('   Token 信息:')
				console.log('   - 版本:', tokenInfo.version)
				console.log('   - 资源:', tokenInfo.res)
				console.log('   - 过期时间:', new Date(tokenInfo.et * 1000).toLocaleString())
				console.log('   - 签名方法:', tokenInfo.method)
				
				if (tokenInfo.et < Date.now() / 1000) {
					results.errors.push('❌ Token 已过期，请重新生成')
					results.isValid = false
				} else {
					const daysLeft = Math.floor((tokenInfo.et - Date.now() / 1000) / 86400)
					console.log('   - 剩余有效期:', daysLeft, '天')
				}
			}
		}

		console.log('\n========== 检查结果 ==========')
		
		if (results.errors.length > 0) {
			console.log('\n❌ 错误（必须修复）:')
			results.errors.forEach(err => console.log('  ', err))
		}

		if (results.warnings.length > 0) {
			console.log('\n⚠️ 警告（建议修复）:')
			results.warnings.forEach(warn => console.log('  ', warn))
		}

		if (results.isValid) {
			console.log('\n✅ 配置检查通过，可以正常使用 OneNET 功能')
		} else {
			console.log('\n❌ 配置检查未通过，请修复上述错误')
		}

		return results
	}

	/**
	 * 解析 Token
	 */
	parseToken(token) {
		try {
			const params = {}
			const pairs = token.split('&')
			
			for (const pair of pairs) {
				const [key, value] = pair.split('=')
				if (key && value) {
					params[key] = decodeURIComponent(value)
				}
			}

			return {
				version: params.version,
				res: params.res,
				et: parseInt(params.et),
				method: params.method,
				sign: params.sign
			}
		} catch (e) {
			console.error('Token 解析失败:', e)
			return null
		}
	}

	/**
	 * 遮罩敏感字符串
	 */
	maskString(str) {
		if (!str || str.length < 8) return '***'
		return str.substring(0, 4) + '****' + str.substring(str.length - 4)
	}

	/**
	 * 测试连接（可选）
	 */
	async testConnection() {
		console.log('\n========== 连接测试 ==========\n')
		
		try {
			const { oneNetClient } = require('./onenet-simple.js')
			
			// 尝试上报一条测试数据
			const testData = {
				heart_rate: 75,
				blood_oxygen: 98
			}

			console.log('正在测试数据上报...')
			const result = await oneNetClient.uploadProperty(testData)
			
			if (result.success) {
				console.log('✅ 连接测试成功！数据上报正常')
				return true
			} else {
				console.log('❌ 连接测试失败:', result.error)
				return false
			}
		} catch (error) {
			console.log('❌ 连接测试失败:', error.message)
			return false
		}
	}
}

// 如果直接运行此文件
if (require.main === module) {
	const checker = new OneNetConfigChecker()
	const results = checker.checkConfig()
	
	if (results.isValid) {
		// 配置正确，可选进行连接测试
		console.log('\n是否进行连接测试？(需要网络)')
		console.log('如需测试，请调用 checker.testConnection()')
	}
}

module.exports = {
	OneNetConfigChecker
}
