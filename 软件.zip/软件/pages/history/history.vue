<template>
	<view class="container">
		<view class="header">
			<text class="title">历史数据</text>
			<text class="clear-btn" @click="clearAllData">清空全部</text>
		</view>
		
		<view class="stats-bar">
			<view class="stat-item">
				<text class="stat-value">{{ healthDataList.length }}</text>
				<text class="stat-label">总记录数</text>
			</view>
			<view class="stat-item">
				<text class="stat-value">{{ normalRecords.length }}</text>
				<text class="stat-label">普通记录</text>
			</view>
			<view class="stat-item">
				<text class="stat-value">{{ runningRecords.length }}</text>
				<text class="stat-label">运动记录</text>
			</view>
		</view>

		<view class="filter-tabs">
			<text 
				class="tab-item" 
				:class="{ active: currentTab === 'all' }"
				@click="currentTab = 'all'"
			>全部</text>
			<text 
				class="tab-item" 
				:class="{ active: currentTab === 'normal' }"
				@click="currentTab = 'normal'"
			>普通记录</text>
			<text 
				class="tab-item" 
				:class="{ active: currentTab === 'running' }"
				@click="currentTab = 'running'"
			>运动记录</text>
		</view>

		<scroll-view class="data-list" scroll-y>
			<view v-if="filteredData.length === 0" class="empty-tip">
				<text>暂无历史数据</text>
			</view>
			
			<view 
				class="data-card" 
				v-for="(item, index) in filteredData" 
				:key="index"
				:class="{ 'normal': item.type === 'normal', 'running': item.type === 'running' }"
			>
				<view class="card-header">
					<text class="card-type">{{ item.type === 'normal' ? '普通记录' : '运动记录' }}</text>
					<text class="card-time">{{ item.datetime }}</text>
				</view>
				
				<view class="card-body" v-if="item.type === 'normal'">
					<view class="data-row">
						<text class="data-label">心率:</text>
						<text class="data-value">{{ item.hr }} bpm</text>
					</view>
					<view class="data-row">
						<text class="data-label">血氧:</text>
						<text class="data-value">{{ item.spo2 }}%</text>
					</view>
					<view class="data-row">
						<text class="data-label">序号:</text>
						<text class="data-value">#{{ item.index }}</text>
					</view>
				</view>
				
				<view class="card-body" v-if="item.type === 'running'">
					<view class="data-row">
						<text class="data-label">步数:</text>
						<text class="data-value">{{ item.steps }} 步</text>
					</view>
					<view class="data-row">
						<text class="data-label">距离:</text>
						<text class="data-value">{{ item.distance }} 米</text>
					</view>
					<view class="data-row">
						<text class="data-label">心率:</text>
						<text class="data-value">{{ item.hr }} bpm</text>
					</view>
					<view class="data-row">
						<text class="data-label">血氧:</text>
						<text class="data-value">{{ item.spo2 }}%</text>
					</view>
					<view class="data-row">
						<text class="data-label">时长:</text>
						<text class="data-value">{{ item.duration }} 秒</text>
					</view>
				</view>
				
				<view class="card-footer">
					<text class="raw-data" @click="showRawData(item.raw)">查看原始数据</text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			healthDataList: [],
			currentTab: 'all'
		}
	},
	computed: {
		normalRecords() {
			return this.healthDataList.filter(item => item.type === 'normal')
		},
		runningRecords() {
			return this.healthDataList.filter(item => item.type === 'running')
		},
		filteredData() {
			if (this.currentTab === 'all') {
				return this.healthDataList
			} else if (this.currentTab === 'normal') {
				return this.normalRecords
			} else {
				return this.runningRecords
			}
		}
	},
	onShow() {
		this.loadHealthData()
	},
	methods: {
		loadHealthData() {
			try {
				const data = uni.getStorageSync('healthDataList')
				if (data) {
					const list = JSON.parse(data)
					this.healthDataList = Array.isArray(list) ? list : []
				} else {
					this.healthDataList = []
				}
			} catch (e) {
				console.error('加载健康数据失败:', e)
				this.healthDataList = []
			}
		},
		
		clearAllData() {
			uni.showModal({
				title: '确认清空',
				content: '确定要清空所有历史数据吗？',
				success: (res) => {
					if (res.confirm) {
						// 先清空本地数据
						this.healthDataList = []
						// 然后清除存储
						uni.removeStorageSync('healthDataList')
						// 强制刷新页面数据
						this.$nextTick(() => {
							this.healthDataList = []
						})
						uni.showToast({
							title: '已清空',
							icon: 'success'
						})
					}
				}
			})
		},
		
		showRawData(raw) {
			uni.showModal({
				title: '原始数据',
				content: raw,
				showCancel: false
			})
		}
	}
}
</script>

<style>
.container {
	padding: 20rpx;
	background-color: #f5f5f5;
	min-height: 100vh;
}

.header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 20rpx;
}

.title {
	font-size: 36rpx;
	font-weight: bold;
	color: #333;
}

.clear-btn {
	font-size: 28rpx;
	color: #ff4d4f;
}

.stats-bar {
	display: flex;
	justify-content: space-around;
	background-color: #fff;
	padding: 30rpx 20rpx;
	border-radius: 16rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

.stat-item {
	display: flex;
	flex-direction: column;
	align-items: center;
}

.stat-value {
	font-size: 40rpx;
	font-weight: bold;
	color: #667eea;
}

.stat-label {
	font-size: 24rpx;
	color: #666;
	margin-top: 10rpx;
}

.filter-tabs {
	display: flex;
	background-color: #fff;
	padding: 15rpx;
	border-radius: 16rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

.tab-item {
	flex: 1;
	text-align: center;
	padding: 20rpx;
	font-size: 28rpx;
	color: #666;
	border-radius: 12rpx;
}

.tab-item.active {
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	color: #fff;
}

.data-list {
	max-height: calc(100vh - 400rpx);
}

.empty-tip {
	text-align: center;
	padding: 100rpx 0;
	color: #999;
	font-size: 28rpx;
}

.data-card {
	background-color: #fff;
	border-radius: 16rpx;
	padding: 25rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
	border-left: 8rpx solid #ccc;
}

.data-card.normal {
	border-left-color: #07c160;
}

.data-card.running {
	border-left-color: #1890ff;
}

.card-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 20rpx;
	padding-bottom: 15rpx;
	border-bottom: 2rpx solid #f0f0f0;
}

.card-type {
	font-size: 28rpx;
	font-weight: bold;
	color: #333;
}

.card-time {
	font-size: 24rpx;
	color: #999;
}

.card-body {
	display: flex;
	flex-direction: column;
	gap: 15rpx;
}

.data-row {
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.data-label {
	font-size: 26rpx;
	color: #666;
}

.data-value {
	font-size: 28rpx;
	font-weight: bold;
	color: #333;
}

.card-footer {
	margin-top: 20rpx;
	padding-top: 15rpx;
	border-top: 2rpx solid #f0f0f0;
	text-align: right;
}

.raw-data {
	font-size: 24rpx;
	color: #667eea;
}
</style>
