<template>
	<view class="container">
		<!-- 蓝牙状态栏 -->
		<view class="status-bar">
			<view class="status-item">
				<text class="status-label">蓝牙状态:</text>
				<text class="status-value" :class="bluetoothEnabled ? 'enabled' : 'disabled'">
					{{ bluetoothEnabled ? '已开启' : '已关闭' }}
				</text>
			</view>
			<view class="status-item">
				<text class="status-label">连接状态:</text>
				<text class="status-value" :class="connectionStatus === '已连接' ? 'connected' : 'disconnected'">
					{{ connectionStatus }}
				</text>
			</view>
		</view>

		<!-- OneNET 配置提示 -->
		<view class="onenet-warning" v-if="showOneNETWarning">
			<text class="warning-text">⚠️ OneNET 配置需要更新，请查看说明文档</text>
		</view>

		<!-- 操作按钮区 -->
		<view class="action-section">
			<button class="btn-primary" @click="initBluetooth" :disabled="isScanning">
				{{ isScanning ? '扫描中...' : '扫描设备' }}
			</button>
			<button class="btn-secondary" @click="stopScan" v-if="isScanning">
				停止扫描
			</button>
			<button class="btn-danger" @click="disconnectDevice" v-if="connectedDevice">
				断开连接
			</button>
		</view>

		<!-- 已连接过的设备列表 -->
		<view class="device-section" v-if="connectedDevices.length > 0 && !connectedDevice">
			<view class="section-title">
				<text>历史设备 ({{ connectedDevices.length }})</text>
				<text class="clear-history" @click="clearConnectedDevices">清空</text>
			</view>
			<scroll-view class="device-list" scroll-y>
				<view 
					class="device-item history-device" 
					v-for="(device, index) in connectedDevices" 
					:key="'history-' + index"
					@click="connectHistoryDevice(device)"
				>
					<view class="device-info">
						<text class="device-name">{{ device.name || '未知设备' }}</text>
						<text class="device-id">{{ device.deviceId }}</text>
						<text class="device-time">上次连接: {{ formatTime(device.connectTime) }}</text>
					</view>
					<view class="device-action">
						<text class="connect-text">快速连接</text>
					</view>
				</view>
			</scroll-view>
		</view>

		<!-- 扫描到的设备列表 -->
		<view class="device-section">
			<view class="section-title">
				<text>可用设备 ({{ devices.length }})</text>
			</view>
			<scroll-view class="device-list" scroll-y>
				<view 
					class="device-item" 
					v-for="(device, index) in devices" 
					:key="index"
					@click="connectDevice(device)"
					:class="{ 'connected': connectedDevice && connectedDevice.deviceId === device.deviceId }"
				>
					<view class="device-info">
						<text class="device-name">{{ device.name || '未知设备' }}</text>
						<text class="device-id">{{ device.deviceId }}</text>
						<text class="device-rssi">信号: {{ device.RSSI }}dBm</text>
					</view>
					<view class="device-action">
						<text class="connect-text">点击连接</text>
					</view>
				</view>
				<view class="empty-tip" v-if="devices.length === 0">
					<text>暂无设备，点击扫描按钮搜索蓝牙设备<br/>或从历史设备快速连接</text>
				</view>
			</scroll-view>
		</view>

		<!-- OneNET 云平台上报入口 -->
		<view class="onenet-section">
			<view class="onenet-header">
				<text class="onenet-title">☁️ OneNET 云平台</text>
				<text class="onenet-status" :class="{ 'uploaded': lastUploadTime }">
					{{ lastUploadTime ? '上次上传: ' + lastUploadTime : '未上传' }}
				</text>
			</view>
			<view class="onenet-mode-select">
				<text class="mode-label">上传模式:</text>
				<view class="mode-options">
					<text 
						class="mode-option" 
						:class="{ active: uploadMode === 'normal' }"
						@click="uploadMode = 'normal'"
					>普通模式</text>
					<text 
						class="mode-option" 
						:class="{ active: uploadMode === 'running' }"
						@click="uploadMode = 'running'"
					>跑步模式</text>
					<text 
						class="mode-option" 
						:class="{ active: uploadMode === 'all' }"
						@click="uploadMode = 'all'"
					>全部</text>
				</view>
			</view>
			<view class="onenet-actions">
				<button class="btn-onenet" @click="uploadToOneNET" :disabled="isUploading || healthDataCount === 0">
					{{ isUploading ? '上传中...' : `上传${uploadMode === 'normal' ? '普通' : uploadMode === 'running' ? '跑步' : ''}数据 (${healthDataCount}条)` }}
				</button>
				<button class="btn-onenet-secondary" @click="viewOneNETData">
					查看云端数据
				</button>
			</view>
			<view class="onenet-config-check">
				<text class="config-check-link" @click="checkOneNETConfig">🔧 检查配置</text>
				<text class="config-check-link" @click="testOneNETConnection" style="margin-left: 20rpx;">🧪 测试连接</text>
				<text class="config-check-link" @click="activateDevice" style="margin-left: 20rpx;">⚡ 激活设备</text>
				<text class="config-check-link" @click="forceActivateDevice" style="margin-left: 20rpx;">🔄 强制激活</text>
				<text class="config-check-link" @click="activateForDataSource" style="margin-left: 20rpx;">📊 数据源激活</text>
			</view>
		</view>

		<!-- 历史数据入口 - 无需连接设备即可查看 -->
		<view class="history-entry-section">
			<view class="history-entry-content" @click="goToHistory">
				<view class="history-entry-icon">
					<text class="icon-text">📊</text>
				</view>
				<view class="history-entry-info">
					<text class="history-entry-title">历史数据</text>
					<text class="history-entry-desc">已保存 {{ healthDataCount }} 条记录</text>
				</view>
				<text class="history-entry-arrow">></text>
			</view>
		</view>

		<!-- 连接信息区 -->
		<view class="info-section" v-if="connectedDevice">
			<view class="section-title">
				<text>连接信息</text>
			</view>
			<view class="info-item">
				<text class="info-label">服务UUID:</text>
				<text class="info-value">{{ serviceId || '未获取' }}</text>
			</view>
			<view class="info-item">
				<text class="info-label">写入特征:</text>
				<text class="info-value">{{ characteristicId || '未获取' }}</text>
			</view>
			<view class="info-item">
				<text class="info-label">通知特征:</text>
				<text class="info-value">{{ notifyCharacteristicId || '未获取' }}</text>
			</view>
		</view>

		<!-- 数据通信区 -->
		<view class="data-section" v-if="connectedDevice">
			<view class="section-title">
				<text>数据通信</text>
				<text class="data-stats">接收: {{ receiveCount }}条</text>
			</view>
			
			<!-- 数据包设置 -->
			<view class="packet-config">
				<view class="config-row">
					<text class="config-label">分包合并:</text>
					<switch :checked="enablePacketMerge" @change="enablePacketMerge = $event.detail.value" color="#667eea"/>
					<text class="config-hint">{{ enablePacketMerge ? '开启' : '关闭' }}</text>
				</view>
				<view class="config-row" v-if="enablePacketMerge">
					<text class="config-label">结束符(Hex):</text>
					<input class="config-input" v-model="packetEndMarker" placeholder="如: 0A 0D" maxlength="20"/>
					<text class="config-label">超时(ms):</text>
					<input class="config-input timeout-input" v-model.number="packetTimeout" type="number" placeholder="100"/>
				</view>
			</view>
			
			<!-- 接收数据 -->
			<view class="data-display">
				<view class="data-header">
					<text class="data-label">接收到的数据:</text>
					<view class="format-controls">
						<view class="encoding-select">
							<text class="select-label">编码:</text>
							<picker class="picker" mode="selector" :range="encodingOptions" :value="encodingIndex" @change="onEncodingChange">
								<view class="picker-value">{{ receiveEncoding }}</view>
							</picker>
						</view>
						<view class="format-toggle">
							<text 
								class="toggle-item" 
								:class="{ 'active': receiveFormat === 'string' }"
								@click="receiveFormat = 'string'"
							>字符串</text>
							<text 
								class="toggle-item" 
								:class="{ 'active': receiveFormat === 'hex' }"
								@click="receiveFormat = 'hex'"
							>十六进制</text>
						</view>
						<text class="copy-btn" @click="copyReceiveData">复制</text>
					</view>
				</view>
				<scroll-view class="receive-box" scroll-y scroll-with-animation :scroll-top="receiveScrollTop">
					<view v-if="receiveList.length === 0" class="empty-receive">
						<text>等待接收数据...</text>
					</view>
					<view 
						class="receive-item" 
						v-for="(item, index) in receiveList" 
						:key="item.id || index"
						:class="{ 'merged-packet': item.isMerged, 'raw-packet': !item.isMerged }"
					>
						<view class="packet-header">
							<text class="receive-time">{{ item.time }}</text>
							<text class="packet-type" v-if="item.isMerged">[完整包]</text>
							<text class="packet-type raw" v-else>[原始]</text>
							<text class="packet-size">{{ item.size }}字节</text>
							<text class="packet-count" v-if="item.packetCount">({{ item.packetCount }}段)</text>
						</view>
						<text class="receive-content selectable">{{ receiveFormat === 'hex' ? item.hex : item.decoded }}</text>
						<text class="receive-hex selectable" v-if="receiveFormat === 'string' && item.hex">HEX: {{ item.hex }}</text>
					</view>
				</scroll-view>
			</view>

			<!-- 发送数据 -->
			<view class="send-section">
				<view class="send-header">
					<text class="send-label">发送格式 (UTF-8):</text>
					<view class="format-toggle">
						<text 
							class="toggle-item" 
							:class="{ 'active': sendFormat === 'string' }"
							@click="sendFormat = 'string'"
						>字符串</text>
						<text 
							class="toggle-item" 
							:class="{ 'active': sendFormat === 'hex' }"
							@click="sendFormat = 'hex'"
						>十六进制</text>
					</view>
				</view>
				<view class="send-input-area">
					<input 
						class="send-input" 
						v-model="sendData" 
						:placeholder="sendFormat === 'string' ? '输入要发送的字符串 (UTF-8)' : '输入十六进制，如: 01 02 03'"
						confirm-type="send"
						@confirm="sendToDevice"
					/>
					<button class="btn-send" @click="sendToDevice" :disabled="!sendData || isSending">
						{{ isSending ? '发送中...' : '发送' }}
					</button>
				</view>
			</view>

			<!-- 时间同步 -->
			<view class="time-sync-section">
				<text class="sync-label">时间同步:</text>
				<button class="btn-sync" @click="syncTime">
					同步时间
				</button>
				<text class="sync-format">格式: $YYMMDDWHHMMSS#</text>
			</view>

			<!-- 历史数据 -->
			<view class="history-section">
				<text class="history-label">数据管理:</text>
				<button class="btn-history" @click="goToHistory">
					查看历史数据 ({{ healthDataCount }})
				</button>
			</view>

			<!-- 指令发送 -->
			<view class="command-section">
				<text class="command-label">指令控制:</text>
				<button class="btn-get" @click="sendGetCommand">
					发送 GET
				</button>
			</view>
		</view>

		<!-- 日志区 -->
		<view class="log-section">
			<view class="section-title">
				<text>操作日志</text>
				<view class="log-actions">
					<text class="copy-log-btn" @click="copyLogs">复制</text>
					<text class="clear-log" @click="clearLogs">清空</text>
				</view>
			</view>
			<scroll-view class="log-box" scroll-y>
				<view class="log-item selectable" v-for="(log, index) in logs" :key="index">
					<text class="log-time">{{ log.time }}</text>
					<text class="log-content" :class="log.type">{{ log.content }}</text>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			bluetoothEnabled: false,
			isScanning: false,
			devices: [],
			connectedDevice: null,
			connectionStatus: '未连接',
			sendData: '',
			receivedData: '',
			receiveList: [],
			receiveCount: 0,
			receiveFormat: 'string',
			sendFormat: 'string',
			isSending: false,
			receiveScrollTop: 0,
			logs: [],
			serviceId: '',
			characteristicId: '',
			notifyCharacteristicId: '',
			writeType: 'write',
			// 编码选项
			receiveEncoding: 'UTF-8',
			encodingOptions: ['UTF-8', 'GBK', 'GB2312', 'GB18030', 'ASCII', 'Unicode', 'Hex'],
			encodingIndex: 0,
			// 数据包合并配置
			enablePacketMerge: true,
			packetEndMarker: '0A 0D',
			packetTimeout: 100,
			// 健康数据计数
			healthDataCount: 0,
			// 数据包缓存
			packetBuffer: [],
			packetTimer: null,
			lastPacketHex: '',
			packetId: 0,
			// 已连接过的设备列表
			connectedDevices: [],
			// OneNET 上传状态
			isUploading: false,
			lastUploadTime: '',
			// OneNET 配置提示
			showOneNETWarning: false,
			// 上传模式: normal-普通, running-跑步, all-全部
			uploadMode: 'all'
		}
	},

	// OneNET 配置（直接内联，避免 require 问题）
	ONE_NET_CONFIG: {
		HTTP_BASE_URL: 'https://open.iot.10086.cn/studio/http',
		PRODUCT_ID: 'fQ88v8SIm9',
		DEVICE_NAME: 'HealthDevice001',
		PRE_GENERATED_TOKEN: 'version=2018-10-31&res=products%2FfQ88v8SIm9%2Fdevices%2FHealthDevice001&et=4765363200&method=sha1&sign=i6BXg0Ckqi7VRl%2FC8d5MrIC61uU%3D'
	},
	onLoad() {
		this.checkBluetoothStatus()
		this.loadHealthDataCount()
		this.loadConnectedDevices()
		this.loadLastUploadTime()
	},

	onShow() {
		// 每次显示页面时刷新健康数据计数
		this.loadHealthDataCount()
	},

	onUnload() {
		this.stopScan()
		if (this.connectedDevice) {
			this.disconnectDevice()
		}
		this.clearPacketBuffer()
	},
	methods: {
		loadHealthDataCount() {
			try {
				const data = uni.getStorageSync('healthDataList')
				if (data) {
					const list = JSON.parse(data)
					this.healthDataCount = Array.isArray(list) ? list.length : 0
				} else {
					this.healthDataCount = 0
				}
			} catch (e) {
				console.error('加载健康数据计数失败:', e)
				this.healthDataCount = 0
			}
		},

		// 加载已连接设备列表
		loadConnectedDevices() {
			try {
				const data = uni.getStorageSync('connectedDevices')
				if (data) {
					const list = JSON.parse(data)
					this.connectedDevices = Array.isArray(list) ? list : []
					this.addLog(`已加载 ${this.connectedDevices.length} 个历史设备`, 'info')
				} else {
					this.connectedDevices = []
				}
			} catch (e) {
				console.error('加载已连接设备失败:', e)
				this.connectedDevices = []
			}
		},

		// 保存已连接设备
		saveConnectedDevice(device) {
			try {
				let deviceList = []
				const data = uni.getStorageSync('connectedDevices')
				if (data) {
					deviceList = JSON.parse(data)
					if (!Array.isArray(deviceList)) {
						deviceList = []
					}
				}
				
				// 检查是否已存在，如果存在则更新连接时间
				const existsIndex = deviceList.findIndex(item => item.deviceId === device.deviceId)
				if (existsIndex !== -1) {
					// 更新已有设备的连接时间并移到最前面
					const existingDevice = deviceList.splice(existsIndex, 1)[0]
					existingDevice.connectTime = new Date().toISOString()
					deviceList.unshift(existingDevice)
				} else {
					// 添加新设备
					deviceList.unshift({
						deviceId: device.deviceId,
						name: device.name || '未知设备',
						connectTime: new Date().toISOString()
					})
					// 最多保存10个设备
					if (deviceList.length > 10) {
						deviceList.pop()
					}
					this.addLog(`已保存设备: ${device.name || device.deviceId}`, 'success')
				}
				
				uni.setStorageSync('connectedDevices', JSON.stringify(deviceList))
				// 更新本地列表
				this.connectedDevices = deviceList
			} catch (e) {
				console.error('保存设备失败:', e)
			}
		},

		// 清空已连接设备列表
		clearConnectedDevices() {
			uni.showModal({
				title: '确认清空',
				content: '确定要清空历史设备列表吗？',
				success: (res) => {
					if (res.confirm) {
						uni.removeStorageSync('connectedDevices')
						this.connectedDevices = []
						this.addLog('已清空历史设备列表', 'info')
						uni.showToast({
							title: '已清空',
							icon: 'success'
						})
					}
				}
			})
		},

		// 连接历史设备
		connectHistoryDevice(device) {
			if (this.connectedDevice) {
				uni.showToast({
					title: '请先断开当前连接',
					icon: 'none'
				})
				return
			}

			// 先初始化蓝牙适配器
			uni.openBluetoothAdapter({
				success: (res) => {
					this.bluetoothEnabled = true
					this.addLog('蓝牙适配器初始化成功', 'success')
					// 直接连接历史设备
					this.doConnectDevice(device)
				},
				fail: (err) => {
					this.bluetoothEnabled = false
					this.addLog('蓝牙适配器初始化失败: ' + err.errMsg, 'error')
					uni.showToast({
						title: '请开启蓝牙',
						icon: 'none'
					})
				}
			})
		},

		// 格式化时间显示
		formatTime(isoString) {
			if (!isoString) return '未知时间'
			try {
				const date = new Date(isoString)
				const now = new Date()
				const diff = now - date
				
				// 小于1分钟
				if (diff < 60000) {
					return '刚刚'
				}
				// 小于1小时
				if (diff < 3600000) {
					return Math.floor(diff / 60000) + '分钟前'
				}
				// 小于24小时
				if (diff < 86400000) {
					return Math.floor(diff / 3600000) + '小时前'
				}
				// 小于7天
				if (diff < 604800000) {
					return Math.floor(diff / 86400000) + '天前'
				}
				
				// 显示具体日期
				const month = (date.getMonth() + 1).toString().padStart(2, '0')
				const day = date.getDate().toString().padStart(2, '0')
				const hour = date.getHours().toString().padStart(2, '0')
				const minute = date.getMinutes().toString().padStart(2, '0')
				return `${month}-${day} ${hour}:${minute}`
			} catch (e) {
				return '未知时间'
			}
		},

		addLog(content, type = 'info') {
			const now = new Date()
			const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`
			this.logs.unshift({ time, content, type })
			if (this.logs.length > 100) {
				this.logs.pop()
			}
		},

		clearLogs() {
			this.logs = []
		},

		clearReceiveData() {
			this.receiveList = []
			this.receiveCount = 0
			this.clearPacketBuffer()
			this.addLog('已清空接收数据', 'info')
		},

		// 复制所有接收数据
		copyReceiveData() {
			if (this.receiveList.length === 0) {
				uni.showToast({
					title: '没有数据可复制',
					icon: 'none'
				})
				return
			}

			let text = ''
			this.receiveList.forEach((item, index) => {
				text += `[${item.time}] ${item.decoded}\n`
				if (item.hex) {
					text += `HEX: ${item.hex}\n`
				}
				text += '\n'
			})

			uni.setClipboardData({
				data: text,
				success: () => {
					uni.showToast({
						title: '已复制到剪贴板',
						icon: 'success'
					})
					this.addLog('已复制所有接收数据到剪贴板', 'success')
				},
				fail: () => {
					uni.showToast({
						title: '复制失败',
						icon: 'none'
					})
				}
			})
		},

		// 复制单条数据包
		copySinglePacket(item) {
			let text = `[${item.time}]\n`
			text += `数据: ${item.decoded}\n`
			if (item.hex) {
				text += `HEX: ${item.hex}\n`
			}
			text += `大小: ${item.size}字节`

			uni.setClipboardData({
				data: text,
				success: () => {
					uni.showToast({
						title: '已复制该条数据',
						icon: 'success'
					})
				},
				fail: () => {
					uni.showToast({
						title: '复制失败',
						icon: 'none'
					})
				}
			})
		},

		// 复制所有日志
		copyLogs() {
			if (this.logs.length === 0) {
				uni.showToast({
					title: '没有日志可复制',
					icon: 'none'
				})
				return
			}

			let text = ''
			this.logs.forEach(log => {
				text += `[${log.time}] ${log.content}\n`
			})

			uni.setClipboardData({
				data: text,
				success: () => {
					uni.showToast({
						title: '已复制到剪贴板',
						icon: 'success'
					})
				},
				fail: () => {
					uni.showToast({
						title: '复制失败',
						icon: 'none'
					})
				}
			})
		},

		// 复制单条日志
		copySingleLog(log) {
			const text = `[${log.time}] ${log.content}`

			uni.setClipboardData({
				data: text,
				success: () => {
					uni.showToast({
						title: '已复制该条日志',
						icon: 'success'
					})
				},
				fail: () => {
					uni.showToast({
						title: '复制失败',
						icon: 'none'
					})
				}
			})
		},

		clearPacketBuffer() {
			if (this.packetTimer) {
				clearTimeout(this.packetTimer)
				this.packetTimer = null
			}
			this.packetBuffer = []
			this.lastPacketHex = ''
		},

		// 编码选择改变
		onEncodingChange(e) {
			this.encodingIndex = e.detail.value
			this.receiveEncoding = this.encodingOptions[this.encodingIndex]
			this.addLog(`接收编码切换为: ${this.receiveEncoding}`, 'info')
			// 重新解码已有数据
			this.redecodeReceiveList()
		},

		// 重新解码接收列表
		redecodeReceiveList() {
			this.receiveList = this.receiveList.map(item => {
				if (item.rawBuffers) {
					const mergedBuffer = this.mergeArrayBuffers(item.rawBuffers)
					return {
						...item,
						decoded: this.decodeBuffer(mergedBuffer, this.receiveEncoding),
						hex: this.arrayBufferToHex(mergedBuffer)
					}
				}
				return {
					...item,
					decoded: this.decodeBuffer(item.rawBuffer, this.receiveEncoding)
				}
			})
		},

		checkBluetoothStatus() {
			uni.openBluetoothAdapter({
				success: (res) => {
					this.bluetoothEnabled = true
					this.addLog('蓝牙适配器初始化成功', 'success')
				},
				fail: (err) => {
					this.bluetoothEnabled = false
					this.addLog('蓝牙适配器初始化失败: ' + err.errMsg, 'error')
					if (err.errCode === 10001) {
						uni.showModal({
							title: '提示',
							content: '请开启手机蓝牙',
							showCancel: false
						})
					}
				}
			})
		},

		initBluetooth() {
			this.devices = []
			uni.openBluetoothAdapter({
				success: (res) => {
					this.bluetoothEnabled = true
					this.addLog('蓝牙适配器初始化成功', 'success')
					this.startScan()
				},
				fail: (err) => {
					this.bluetoothEnabled = false
					this.addLog('蓝牙适配器初始化失败: ' + err.errMsg, 'error')
					uni.showToast({
						title: '请开启蓝牙',
						icon: 'none'
					})
				}
			})
		},

		startScan() {
			this.isScanning = true
			this.addLog('开始扫描设备...', 'info')
			
			uni.onBluetoothDeviceFound((res) => {
				res.devices.forEach(device => {
					if (device.name && device.name.length > 0) {
						const index = this.devices.findIndex(d => d.deviceId === device.deviceId)
						if (index === -1) {
							this.devices.push(device)
							this.addLog(`发现设备: ${device.name} (${device.deviceId})`, 'success')
						} else {
							this.devices[index] = device
						}
					}
				})
			})

			uni.startBluetoothDevicesDiscovery({
				allowDuplicatesKey: false,
				success: (res) => {
					this.addLog('扫描已开始', 'success')
				},
				fail: (err) => {
					this.isScanning = false
					this.addLog('扫描失败: ' + err.errMsg, 'error')
				}
			})

			setTimeout(() => {
				if (this.isScanning) {
					this.stopScan()
				}
			}, 10000)
		},

		stopScan() {
			uni.stopBluetoothDevicesDiscovery({
				success: (res) => {
					this.isScanning = false
					this.addLog('扫描已停止', 'info')
				}
			})
		},

		connectDevice(device) {
			if (this.connectedDevice) {
				uni.showToast({
					title: '请先断开当前连接',
					icon: 'none'
				})
				return
			}

			this.stopScan()
			this.doConnectDevice(device)
		},

		// 实际执行连接操作
		doConnectDevice(device) {
			this.addLog(`正在连接 ${device.name || device.deviceId}...`, 'info')
			
			uni.showLoading({
				title: '连接中...'
			})

			uni.createBLEConnection({
				deviceId: device.deviceId,
				timeout: 10000,
				success: (res) => {
					this.connectedDevice = device
					this.connectionStatus = '已连接'
					this.addLog(`连接 ${device.name || device.deviceId} 成功`, 'success')
					// 保存到已连接设备列表
					this.saveConnectedDevice(device)
					setTimeout(() => {
						this.getServices(device.deviceId)
					}, 500)
				},
				fail: (err) => {
					this.addLog('连接失败: ' + err.errMsg, 'error')
					uni.showToast({
						title: '连接失败: ' + err.errMsg,
						icon: 'none'
					})
				},
				complete: () => {
					uni.hideLoading()
				}
			})
		},

		getServices(deviceId) {
			uni.getBLEDeviceServices({
				deviceId: deviceId,
				success: (res) => {
					this.addLog(`发现 ${res.services.length} 个服务`, 'info')
					this.addLog(`服务列表: ${res.services.map(s => s.uuid).join(', ')}`, 'info')
					
					if (res.services.length > 0) {
						for (let i = 0; i < res.services.length; i++) {
							this.serviceId = res.services[i].uuid
							this.addLog(`正在获取服务 ${this.serviceId} 的特征值...`, 'info')
							this.getCharacteristics(deviceId, this.serviceId)
						}
					}
				},
				fail: (err) => {
					this.addLog('获取服务失败: ' + err.errMsg, 'error')
				}
			})
		},

		getCharacteristics(deviceId, serviceId) {
			uni.getBLEDeviceCharacteristics({
				deviceId: deviceId,
				serviceId: serviceId,
				success: (res) => {
					this.addLog(`服务 ${serviceId} 发现 ${res.characteristics.length} 个特征值`, 'info')
					
					let writeChar = null
					let notifyChar = null
					
					res.characteristics.forEach(item => {
						const props = []
						if (item.properties.write) props.push('write')
						if (item.properties.writeNoResponse) props.push('writeNoResponse')
						if (item.properties.read) props.push('read')
						if (item.properties.notify) props.push('notify')
						if (item.properties.indicate) props.push('indicate')
						
						this.addLog(`  特征: ${item.uuid} [${props.join(', ')}]`, 'info')
						
						if (item.properties.write && !writeChar) {
							writeChar = item
						}
						if (item.properties.writeNoResponse && !writeChar) {
							writeChar = item
							this.writeType = 'writeNoResponse'
						}
						if ((item.properties.notify || item.properties.indicate) && !notifyChar) {
							notifyChar = item
						}
					})

					if (writeChar) {
						this.characteristicId = writeChar.uuid
						this.addLog(`已设置写入特征: ${this.characteristicId}`, 'success')
					}
					
					if (notifyChar) {
						this.notifyCharacteristicId = notifyChar.uuid
						this.startNotify(deviceId, serviceId, notifyChar.uuid)
					}

					if (!this.characteristicId && !this.notifyCharacteristicId) {
						this.addLog('未找到可用的写入或通知特征值', 'error')
					}
				},
				fail: (err) => {
					this.addLog('获取特征值失败: ' + err.errMsg, 'error')
				}
			})
		},

		startNotify(deviceId, serviceId, characteristicId) {
			uni.notifyBLECharacteristicValueChange({
				deviceId: deviceId,
				serviceId: serviceId,
				characteristicId: characteristicId,
				state: true,
				success: (res) => {
					this.addLog(`已开启通知监听: ${characteristicId}`, 'success')
				},
				fail: (err) => {
					this.addLog('开启监听失败: ' + err.errMsg, 'error')
				}
			})

			uni.onBLECharacteristicValueChange((res) => {
				const hex = this.arrayBufferToHex(res.value)
				
				// 检查是否重复数据
				if (hex === this.lastPacketHex) {
					this.addLog(`忽略重复数据`, 'info')
					return
				}
				this.lastPacketHex = hex
				
				if (this.enablePacketMerge) {
					this.handlePacketMerge(res.value, hex)
				} else {
					this.displayPacket(res.value, hex, false)
				}
			})
		},

		// 处理数据包合并
		handlePacketMerge(buffer, hex) {
			// 添加到缓冲区
			this.packetBuffer.push({
				buffer: buffer,
				hex: hex,
				time: Date.now()
			})
			
			// 检查是否包含结束符
			const endMarker = this.packetEndMarker.replace(/\s+/g, '').toUpperCase()
			const hexUpper = hex.replace(/\s+/g, '').toUpperCase()
			
			if (endMarker && hexUpper.endsWith(endMarker)) {
				// 收到结束符，立即合并显示
				this.flushPacketBuffer()
			} else {
				// 设置超时定时器
				if (this.packetTimer) {
					clearTimeout(this.packetTimer)
				}
				this.packetTimer = setTimeout(() => {
					this.flushPacketBuffer()
				}, this.packetTimeout)
			}
		},

		// 刷新数据包缓冲区
		flushPacketBuffer() {
			if (this.packetBuffer.length === 0) return
			
			if (this.packetTimer) {
				clearTimeout(this.packetTimer)
				this.packetTimer = null
			}
			
			// 合并所有缓冲的数据包
			const buffers = this.packetBuffer.map(p => p.buffer)
			const mergedBuffer = this.mergeArrayBuffers(buffers)
			const mergedHex = this.arrayBufferToHex(mergedBuffer)
			
			this.displayPacket(mergedBuffer, mergedHex, true, buffers)
			
			this.addLog(`合并 ${this.packetBuffer.length} 段数据`, 'success')
			
			// 清空缓冲区
			this.packetBuffer = []
		},

		// 显示数据包
		displayPacket(buffer, hex, isMerged, rawBuffers = null) {
			const decoded = this.decodeBuffer(buffer, this.receiveEncoding)
			
			const now = new Date()
			const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`
			
			this.packetId++
			this.receiveCount++
			
			const packetInfo = {
				id: this.packetId,
				time: time,
				data: decoded,
				decoded: decoded,
				hex: hex,
				rawBuffer: buffer,
				rawBuffers: rawBuffers,
				isMerged: isMerged,
				size: buffer.byteLength,
				packetCount: rawBuffers ? rawBuffers.length : 1
			}
			
			this.receiveList.unshift(packetInfo)
			
			if (this.receiveList.length > 50) {
				this.receiveList.pop()
			}
			
			if (isMerged) {
				this.addLog(`收到完整数据包 [${this.receiveEncoding}] - ${decoded.substring(0, 50)}${decoded.length > 50 ? '...' : ''}`, 'success')
			} else {
				this.addLog(`收到数据 [${this.receiveEncoding}] - ${decoded.substring(0, 50)}${decoded.length > 50 ? '...' : ''}`, 'success')
			}
			this.addLog(`HEX: ${hex.substring(0, 100)}${hex.length > 100 ? '...' : ''}`, 'info')
			
			this.receiveScrollTop = this.receiveScrollTop === 0 ? 1 : 0
			
			// 解析并存储健康数据
			this.parseAndStoreHealthData(decoded)
		},

		// 解析并存储健康数据
		parseAndStoreHealthData(decoded) {
			// 检查是否包含 [DEBUG] 或 [MPU6050] 标记
			const hasDebug = decoded.includes('[DEBUG]')
			const hasMPU = decoded.includes('[MPU6050]')
			
			if (!hasDebug && !hasMPU) {
				return
			}
			
			this.addLog('开始解析传感器数据...', 'info')
			
			// 查找所有 [DEBUG] 标记
			const debugRegex = /\[DEBUG\]/g
			let debugMatch
			const debugPositions = []
			
			while ((debugMatch = debugRegex.exec(decoded)) !== null) {
				debugPositions.push(debugMatch.index)
			}
			
			// 查找所有 [MPU6050] 标记
			const mpuRegex = /\[MPU6050\]/g
			let mpuMatch
			const mpuPositions = []
			
			while ((mpuMatch = mpuRegex.exec(decoded)) !== null) {
				mpuPositions.push(mpuMatch.index)
			}
			
			this.addLog(`找到 ${debugPositions.length} 个 [DEBUG] 标记, ${mpuPositions.length} 个 [MPU6050] 标记`, 'info')
			
			// 处理每个 [DEBUG] 后面的内容
			for (let i = 0; i < debugPositions.length; i++) {
				const startPos = debugPositions[i] + 7 // [DEBUG] 长度为 7
				const endPos = i < debugPositions.length - 1 ? debugPositions[i + 1] : decoded.length
				let content = decoded.substring(startPos, endPos).trim()
				
				// 尝试提取 JSON 对象
				this.extractAndSaveJSON(content)
			}
			
			// 处理每个 [MPU6050] 后面的内容
			for (let i = 0; i < mpuPositions.length; i++) {
				const startPos = mpuPositions[i] + 9 // [MPU6050] 长度为 9
				const endPos = i < mpuPositions.length - 1 ? mpuPositions[i + 1] : decoded.length
				let content = decoded.substring(startPos, endPos).trim()
				
				// 解析 MPU6050 数据
				this.parseMPU6050Data(content)
			}
		},

		// 解析 MPU6050 传感器数据
		parseMPU6050Data(content) {
			// 解析 Raw=xxx, Filtered=xxx, Threshold=xxx, Steps=xxx 格式
			const rawMatch = content.match(/Raw=([\d.]+)/)
			const filteredMatch = content.match(/Filtered=([\d.]+)/)
			const thresholdMatch = content.match(/Threshold=([\d.]+)/)
			const stepsMatch = content.match(/Steps=(\d+)/)
			
			if (rawMatch && filteredMatch && thresholdMatch && stepsMatch) {
				const data = {
					raw: parseFloat(rawMatch[1]),
					filtered: parseFloat(filteredMatch[1]),
					threshold: parseFloat(thresholdMatch[1]),
					steps: parseInt(stepsMatch[1])
				}
				
				// 只在步数变化时记录
				if (data.steps > 0) {
					this.addLog(`检测到步数: ${data.steps}`, 'success')
				}
				
				// 可以在这里添加保存 MPU6050 数据的逻辑
			}
		},

		// 提取并保存 JSON 数据
		extractAndSaveJSON(content) {
			// 查找 JSON 对象的开始和结束
			let braceCount = 0
			let jsonStart = -1
			let jsonEnd = -1
			
			for (let i = 0; i < content.length; i++) {
				if (content[i] === '{') {
					if (braceCount === 0) {
						jsonStart = i
					}
					braceCount++
				} else if (content[i] === '}') {
					braceCount--
					if (braceCount === 0 && jsonStart !== -1) {
						jsonEnd = i + 1
						break
					}
				}
			}
			
			if (jsonStart !== -1 && jsonEnd !== -1) {
				const jsonStr = content.substring(jsonStart, jsonEnd)
				this.addLog(`提取到 JSON: ${jsonStr.substring(0, 100)}...`, 'info')
				
				try {
					const data = JSON.parse(jsonStr)
					this.processHealthData(data, jsonStr)
				} catch (e) {
					this.addLog(`JSON 解析失败: ${e.message}`, 'error')
				}
			}
		},

		// 处理健康数据
		processHealthData(data, jsonStr) {
			this.addLog(`处理数据类型: ${data.data_type || 'unknown'}`, 'info')
			
			// 检查是否是健康数据汇总
			if (data.data_type === 'health_data') {
				this.addLog(`检测到健康数据汇总: 普通记录${data.normal_count || 0}条, 运动记录${data.running_count || 0}条`, 'success')
			}
			
			// 检查是否是普通记录 (有 hr 和 spo2，但没有 steps)
			if (data.hr !== undefined && data.spo2 !== undefined && data.steps === undefined) {
				const record = {
					type: 'normal',
					index: data.index || 0,
					datetime: data.datetime || new Date().toLocaleString(),
					hr: data.hr,
					spo2: data.spo2,
					raw: jsonStr,
					saveTime: new Date().toISOString()
				}
				this.saveHealthRecord(record)
				this.addLog(`保存普通记录: 心率${data.hr}, 血氧${data.spo2}`, 'success')
			}
			
			// 检查是否是运动记录 (有 steps 和 distance)
			if (data.steps !== undefined && data.distance !== undefined) {
				const record = {
					type: 'running',
					index: data.index || 0,
					datetime: data.datetime || new Date().toLocaleString(),
					steps: data.steps,
					distance: data.distance,
					hr: data.hr || 0,
					spo2: data.spo2 || 0,
					duration: data.duration || 0,
					raw: jsonStr,
					saveTime: new Date().toISOString()
				}
				this.saveHealthRecord(record)
				this.addLog(`保存运动记录: 步数${data.steps}, 距离${data.distance}米`, 'success')
			}
			
			// 检查上传状态
			if (data.upload_status) {
				this.addLog(`上传状态: ${data.upload_status}`, 'success')
			}
		},

		// 保存健康记录
		saveHealthRecord(record) {
			try {
				this.addLog(`正在保存记录: type=${record.type}, index=${record.index}`, 'info')
				
				let list = []
				const data = uni.getStorageSync('healthDataList')
				if (data) {
					try {
						list = JSON.parse(data)
						if (!Array.isArray(list)) {
							list = []
						}
					} catch (e) {
						list = []
					}
				}
				
				this.addLog(`当前存储列表长度: ${list.length}`, 'info')
				
				// 检查是否已存在相同记录（根据index和datetime）
				const exists = list.some(item => 
					item.index === record.index && 
					item.datetime === record.datetime && 
					item.type === record.type
				)
				
				if (!exists) {
					list.unshift(record)
					uni.setStorageSync('healthDataList', JSON.stringify(list))
					this.healthDataCount = list.length
					this.addLog(`✓ 健康数据已保存，当前共 ${list.length} 条记录`, 'success')
				} else {
					this.addLog('记录已存在，跳过保存', 'info')
				}
			} catch (e) {
				this.addLog('保存健康数据失败: ' + e.message, 'error')
			}
		},

		// 跳转到历史数据页面
		goToHistory() {
			uni.navigateTo({
				url: '/pages/history/history'
			})
		},

		// 上传数据到 OneNET 云平台
		async uploadToOneNET() {
			if (this.healthDataCount === 0) {
				uni.showToast({
					title: '没有数据可上传',
					icon: 'none'
				})
				return
			}

			this.isUploading = true
			this.addLog('开始上传数据到 OneNET...', 'info')

			try {
				// 获取本地存储的健康数据
				const data = uni.getStorageSync('healthDataList')
				if (!data) {
					throw new Error('没有数据可上传')
				}

				const healthDataList = JSON.parse(data)
				if (!Array.isArray(healthDataList) || healthDataList.length === 0) {
					throw new Error('数据列表为空')
				}

				// 使用内联配置上传
				this.addLog('正在连接 OneNET...', 'info')
				
				// 先按时间排序（最新的在最后）
				const sortedDataList = [...healthDataList].sort((a, b) => {
					const timeA = new Date(a.datetime || a.saveTime).getTime()
					const timeB = new Date(b.datetime || b.saveTime).getTime()
					return timeA - timeB
				})
				
				// 根据上传模式过滤数据
				let filteredDataList = sortedDataList
				if (this.uploadMode !== 'all') {
					filteredDataList = sortedDataList.filter(data => data.type === this.uploadMode)
					if (filteredDataList.length === 0) {
						uni.showToast({
							title: `没有${this.uploadMode === 'normal' ? '普通' : '跑步'}模式的数据`,
							icon: 'none'
						})
						this.isUploading = false
						return
					}
					this.addLog(`已过滤${this.uploadMode === 'normal' ? '普通' : '跑步'}模式数据: ${filteredDataList.length}条`, 'info')
				}
				
				// 获取最新的一条数据
				const latestData = filteredDataList[filteredDataList.length - 1]
				this.addLog(`准备上传最新数据: ${new Date(latestData.datetime || latestData.saveTime).toLocaleString()}`, 'info')
				
				// 检查设备是否已激活（首次上传需要先激活）
				const isFirstUpload = !uni.getStorageSync('onenetDeviceActivated')
				if (isFirstUpload) {
					this.addLog('首次上传，先激活设备...', 'info')
					const activateResult = await this.activateOneNETDevice(latestData)
					if (activateResult.success) {
						uni.setStorageSync('onenetDeviceActivated', true)
						this.addLog('✓ 设备已激活', 'success')
					}
				}
				
				const result = await this.uploadToOneNETDirect([latestData])

				if (result.success) {
					// 记录上传时间
					const now = new Date()
					this.lastUploadTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
					
					// 保存上传记录
					uni.setStorageSync('lastUploadTime', this.lastUploadTime)
					uni.setStorageSync('lastUploadCount', healthDataList.length)

					uni.showToast({
						title: `成功上传 ${healthDataList.length} 条数据`,
						icon: 'success'
					})
					this.addLog(`✓ 成功上传 ${healthDataList.length} 条数据到 OneNET`, 'success')
				} else {
					// 详细记录错误信息
					let errorMsg = '上传失败'
					if (result.error) {
						if (typeof result.error === 'string') {
							errorMsg = result.error
						} else if (result.error.errMsg) {
							errorMsg = result.error.errMsg
						} else if (result.error.msg) {
							errorMsg = result.error.msg
						} else {
							errorMsg = JSON.stringify(result.error)
						}
					}
					this.addLog('✗ 上传失败详情: ' + errorMsg, 'error')
					throw new Error(errorMsg)
				}
			} catch (error) {
				console.error('上传失败:', error)
				uni.showToast({
					title: '上传失败: ' + (error.message || '未知错误'),
					icon: 'none'
				})
				this.addLog('✗ 上传到 OneNET 失败: ' + (error.message || '未知错误'), 'error')
			} finally {
				this.isUploading = false
			}
		},

		// 激活 OneNET 设备（使用单条属性上报）
		async activateOneNETDevice(firstData) {
			const config = this.$options.ONE_NET_CONFIG
			const token = config.PRE_GENERATED_TOKEN
			const topic = `$sys/${config.PRODUCT_ID}/${config.DEVICE_NAME}/thing/property/post`
			
			// 构造单条数据用于激活
			const params = {}
			const timestamp = Date.now()
			
			if (firstData.type === 'normal') {
				params.heart_rate = { value: parseInt(firstData.hr) || 0, time: timestamp }
				params.blood_oxygen = { value: parseInt(firstData.spo2) || 0, time: timestamp }
			} else if (firstData.type === 'running') {
				params.heart_rate = { value: parseInt(firstData.hr) || 0, time: timestamp }
				params.blood_oxygen = { value: parseInt(firstData.spo2) || 0, time: timestamp }
				params.steps = { value: parseInt(firstData.steps) || 0, time: timestamp }
				params.distance = { value: parseInt(firstData.distance) || 0, time: timestamp }
			}
			
			const oneJson = {
				id: Date.now().toString(),
				version: '1.0',
				params: params
			}
			
			const fullUrl = `${config.HTTP_BASE_URL}/device/thing/property/post?topic=${encodeURIComponent(topic)}&protocol=HTTP`
			
			return new Promise((resolve, reject) => {
				uni.request({
					url: fullUrl,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
						'token': token
					},
					data: oneJson,
					timeout: 30000,
					success: (res) => {
						if (res.statusCode === 200 && res.data) {
							const errorCode = res.data.code !== undefined ? res.data.code : res.data.errno
							if (errorCode === 0) {
								resolve({ success: true, data: res.data })
							} else {
								resolve({ success: false, error: res.data })
							}
						} else {
							resolve({ success: false, error: res })
						}
					},
					fail: (err) => {
						resolve({ success: false, error: err })
					}
				})
			})
		},

		// 使用设备上线接口激活设备（用于数据源模板）
		async activateDeviceForDataSource() {
			const config = this.$options.ONE_NET_CONFIG
			const token = config.PRE_GENERATED_TOKEN
			
			// 设备上线 topic
			const topic = `$sys/${config.PRODUCT_ID}/${config.DEVICE_NAME}/thing/property/post`
			
			// 构造设备上线数据（使用物模型中已定义的属性）
			const oneJson = {
				id: Date.now().toString(),
				version: '1.0',
				params: {
					heart_rate: {
						value: 75,
						time: Date.now()
					},
					blood_oxygen: {
						value: 98,
						time: Date.now()
					}
				}
			}
			
			const fullUrl = `${config.HTTP_BASE_URL}/device/thing/property/post?topic=${encodeURIComponent(topic)}&protocol=HTTP`
			
			this.addLog('正在通过设备上线接口激活...', 'info')
			
			return new Promise((resolve, reject) => {
				uni.request({
					url: fullUrl,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
						'token': token
					},
					data: oneJson,
					timeout: 30000,
					success: (res) => {
						console.log('设备上线响应:', res)
						if (res.statusCode === 200 && res.data) {
							const errorCode = res.data.code !== undefined ? res.data.code : res.data.errno
							if (errorCode === 0) {
								this.addLog('✓ 设备上线成功', 'success')
								resolve({ success: true, data: res.data })
							} else {
								this.addLog(`✗ 设备上线失败: ${res.data.msg || res.data.error}`, 'error')
								resolve({ success: false, error: res.data })
							}
						} else {
							resolve({ success: false, error: res })
						}
					},
					fail: (err) => {
						this.addLog(`✗ 设备上线请求失败: ${err.errMsg}`, 'error')
						resolve({ success: false, error: err })
					}
				})
			})
		},

		// 直接上传数据到 OneNET（使用单条属性上报，更可靠）
		async uploadToOneNETDirect(dataList) {
			const config = this.$options.ONE_NET_CONFIG
			const token = config.PRE_GENERATED_TOKEN
			const topic = `$sys/${config.PRODUCT_ID}/${config.DEVICE_NAME}/thing/property/post`
			
			this.addLog(`准备上传 ${dataList.length} 条数据...`, 'info')
			
			// 只上传最新的一条数据（OneNET 物模型只显示最新值）
			const latestData = dataList[dataList.length - 1]
			const timestamp = new Date(latestData.datetime || latestData.saveTime).getTime() || Date.now()
			
			// 构造单条数据（确保值为整数）
			const params = {}
			if (latestData.type === 'normal') {
				params.heart_rate = { value: parseInt(latestData.hr) || 0, time: timestamp }
				params.blood_oxygen = { value: parseInt(latestData.spo2) || 0, time: timestamp }
			} else if (latestData.type === 'running') {
				params.heart_rate = { value: parseInt(latestData.hr) || 0, time: timestamp }
				params.blood_oxygen = { value: parseInt(latestData.spo2) || 0, time: timestamp }
				params.steps = { value: parseInt(latestData.steps) || 0, time: timestamp }
				params.distance = { value: parseInt(latestData.distance) || 0, time: timestamp }
			}
			
			const oneJson = {
				id: Date.now().toString(),
				version: '1.0',
				params: params
			}
			
			const jsonStr = JSON.stringify(oneJson)
			this.addLog(`数据大小: ${jsonStr.length} 字节`, 'info')
			console.log('上报数据:', JSON.stringify(oneJson, null, 2))
			
			return new Promise((resolve, reject) => {
				const fullUrl = `${config.HTTP_BASE_URL}/device/thing/property/post?topic=${encodeURIComponent(topic)}&protocol=HTTP`
				
				this.addLog(`请求 URL: ${fullUrl.substring(0, 50)}...`, 'info')
				this.addLog(`Token: ${token.substring(0, 30)}...`, 'info')
				
				uni.request({
					url: fullUrl,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
						'token': token
					},
					data: oneJson,
					timeout: 30000, // 30秒超时
					success: (res) => {
						console.log('OneNET 响应:', res)
						console.log('响应数据:', JSON.stringify(res.data, null, 2))
						this.addLog(`服务器响应: HTTP ${res.statusCode}`, 'info')
						
						if (res.statusCode === 200) {
							if (!res.data) {
								this.addLog('✗ 服务器返回空数据', 'error')
								resolve({ success: false, error: { msg: '服务器返回空数据' } })
								return
							}
							
							// 如果是字符串，尝试解析
							let responseData = res.data
							if (typeof res.data === 'string') {
								try {
									responseData = JSON.parse(res.data)
								} catch (e) {
									this.addLog('✗ 响应不是有效的 JSON', 'error')
									resolve({ success: false, error: { msg: '响应格式错误' } })
									return
								}
							}
							
							// 支持两种响应格式：code 或 errno
							const errorCode = responseData.code !== undefined ? responseData.code : responseData.errno
							
							if (errorCode === undefined) {
								this.addLog('✗ 响应缺少 code/errno 字段', 'error')
								this.addLog('响应内容: ' + JSON.stringify(responseData).substring(0, 200), 'error')
								resolve({ success: false, error: { msg: '响应格式异常', data: responseData } })
								return
							}
							
							if (errorCode === 0) {
								this.addLog('✓ 服务器返回成功', 'success')
								resolve({ success: true, data: responseData })
							} else {
								const errorMsg = responseData.msg || responseData.error || '未知错误'
								this.addLog(`✗ 服务器返回错误码: ${errorCode}`, 'error')
								this.addLog(`错误信息: ${errorMsg}`, 'error')
								resolve({ success: false, error: responseData })
							}
						} else {
							this.addLog(`✗ HTTP 错误: ${res.statusCode}`, 'error')
							resolve({ success: false, error: res })
						}
					},
					fail: (err) => {
						console.error('请求失败:', err)
						this.addLog(`✗ 网络请求失败: ${err.errMsg || '未知错误'}`, 'error')
						resolve({ success: false, error: err })
					}
				})
			})
		},

		// 查看 OneNET 云端数据
		viewOneNETData() {
			const config = this.$options.ONE_NET_CONFIG
			const productId = config.PRODUCT_ID
			const deviceName = config.DEVICE_NAME
			
			if (productId === 'your_product_id_here') {
				uni.showModal({
					title: '提示',
					content: '请先配置 OneNET 产品ID和设备名称',
					showCancel: false
				})
				return
			}

			// 打开 OneNET 控制台页面
			const url = `https://open.iot.10086.cn/studio/device/${productId}/device/${deviceName}/detail`
			
			uni.showModal({
				title: '查看云端数据',
				content: '将跳转到 OneNET 控制台查看设备数据',
				success: (res) => {
					if (res.confirm) {
						// 复制链接到剪贴板
						uni.setClipboardData({
							data: url,
							success: () => {
								uni.showToast({
									title: '链接已复制',
									icon: 'success'
								})
							}
						})
					}
				}
			})
		},

		// 加载上次上传时间
		loadLastUploadTime() {
			try {
				const time = uni.getStorageSync('lastUploadTime')
				if (time) {
					this.lastUploadTime = time
				}
			} catch (e) {
				console.error('加载上传时间失败:', e)
			}
		},

		// 检查 OneNET 配置
		checkOneNETConfig() {
			try {
				const config = this.$options.ONE_NET_CONFIG
				
				let message = 'OneNET 配置检查\n\n'
				let hasError = false
				
				// 检查产品ID
				if (!config.PRODUCT_ID || config.PRODUCT_ID === 'your_product_id_here') {
					message += '❌ PRODUCT_ID 未配置\n'
					hasError = true
				} else {
					message += `✅ PRODUCT_ID: ${config.PRODUCT_ID}\n`
				}
				
				// 检查设备名称
				if (!config.DEVICE_NAME || config.DEVICE_NAME === 'your_device_name_here') {
					message += '❌ DEVICE_NAME 未配置\n'
					hasError = true
				} else {
					message += `✅ DEVICE_NAME: ${config.DEVICE_NAME}\n`
				}
				
				// 检查 Token
				if (!config.PRE_GENERATED_TOKEN) {
					message += '❌ PRE_GENERATED_TOKEN 未配置\n'
					hasError = true
				} else {
					const tokenPreview = config.PRE_GENERATED_TOKEN.substring(0, 20) + '...'
					message += `✅ PRE_GENERATED_TOKEN: ${tokenPreview}\n`
					
					// 解析 Token 检查有效期
					try {
						const params = {}
						const pairs = config.PRE_GENERATED_TOKEN.split('&')
						for (const pair of pairs) {
							const [key, value] = pair.split('=')
							if (key && value) {
								params[key] = decodeURIComponent(value)
							}
						}
						
						if (params.et) {
							const expireTime = parseInt(params.et) * 1000
							const expireDate = new Date(expireTime)
							const now = Date.now()
							
							if (expireTime < now) {
								message += '❌ Token 已过期\n'
								hasError = true
								} else {
								const daysLeft = Math.floor((expireTime - now) / 86400000)
								message += `✅ Token 有效期至: ${expireDate.toLocaleString()}（剩余 ${daysLeft} 天）\n`
							}
						}
					} catch (e) {
						message += '⚠️ Token 解析失败\n'
					}
				}
				
				message += '\n'
				if (hasError) {
					message += '请完成配置后再使用 OneNET 功能\n'
					message += '查看文档：ONENET_QUICK_START.md'
				} else {
					message += '✅ 配置检查通过，可以正常使用'
				}
				
				uni.showModal({
					title: 'OneNET 配置检查',
					content: message,
					showCancel: false
				})
				
				this.addLog('OneNET 配置检查完成', hasError ? 'error' : 'success')
			} catch (error) {
				uni.showModal({
					title: '检查失败',
					content: '配置检查出错: ' + error.message,
					showCancel: false
				})
			}
		},

		// 手动激活设备
		async activateDevice() {
			this.addLog('开始激活设备...', 'info')
			
			// 构造测试数据用于激活
			const testData = {
				type: 'normal',
				hr: 75,
				spo2: 98,
				datetime: new Date().toISOString()
			}
			
			const result = await this.activateOneNETDevice(testData)
			
			if (result.success) {
				uni.setStorageSync('onenetDeviceActivated', true)
				uni.showModal({
					title: '激活成功',
					content: '✅ 设备已成功激活！\n\n现在可以正常上传数据了。',
					showCancel: false
				})
				this.addLog('✓ 设备激活成功', 'success')
			} else {
				const errorMsg = result.error?.msg || result.error?.error || '未知错误'
				uni.showModal({
					title: '激活失败',
					content: `❌ 设备激活失败: ${errorMsg}`,
					showCancel: false
				})
				this.addLog('✗ 设备激活失败: ' + errorMsg, 'error')
			}
		},

		// 强制激活设备（清除本地标记重新激活）
		async forceActivateDevice() {
			uni.showModal({
				title: '强制激活',
				content: '确定要强制重新激活设备吗？',
				success: async (res) => {
					if (res.confirm) {
						// 清除激活标记
						uni.removeStorageSync('onenetDeviceActivated')
						this.addLog('已清除激活标记，重新激活设备...', 'info')
						
						// 构造测试数据用于激活
						const testData = {
							type: 'normal',
							hr: 75,
							spo2: 98,
							datetime: new Date().toISOString()
						}
						
						const result = await this.activateOneNETDevice(testData)
						
						if (result.success) {
							uni.setStorageSync('onenetDeviceActivated', true)
							uni.showModal({
								title: '强制激活成功',
								content: '✅ 设备已成功重新激活！\n\n请刷新 OneNET 控制台查看状态。',
								showCancel: false
							})
							this.addLog('✓ 设备强制激活成功', 'success')
						} else {
							const errorMsg = result.error?.msg || result.error?.error || '未知错误'
							uni.showModal({
								title: '激活失败',
								content: `❌ 设备激活失败: ${errorMsg}`,
								showCancel: false
							})
							this.addLog('✗ 设备激活失败: ' + errorMsg, 'error')
						}
					}
				}
			})
		},

		// 数据源模板专用激活
		async activateForDataSource() {
			this.addLog('开始数据源模板激活流程...', 'info')
			
			// 先尝试设备上线激活
			const result = await this.activateDeviceForDataSource()
			
			if (result.success) {
				uni.setStorageSync('onenetDeviceActivated', true)
				uni.showModal({
					title: '激活成功',
					content: '✅ 设备已成功激活！\n\n现在可以使用数据源模板了。\n\n请刷新 OneNET 控制台查看设备状态。',
					showCancel: false
				})
				this.addLog('✓ 设备激活成功，可以使用数据源模板', 'success')
			} else {
				// 详细记录错误信息
				let errorDetail = '未知错误'
				if (result.error) {
					if (typeof result.error === 'string') {
						errorDetail = result.error
					} else if (result.error.errMsg) {
						errorDetail = result.error.errMsg
					} else if (result.error.msg) {
						errorDetail = result.error.msg
					} else if (result.error.error) {
						errorDetail = result.error.error
					} else {
						errorDetail = JSON.stringify(result.error)
					}
				}
				
				this.addLog('✗ 设备激活失败: ' + errorDetail, 'error')
				
				uni.showModal({
					title: '激活失败',
					content: `❌ 设备激活失败:\n${errorDetail}\n\n请检查:\n1. Token 是否正确\n2. 网络连接是否正常\n3. OneNET 服务是否可用`,
					showCancel: true,
					cancelText: '复制错误',
					confirmText: '确定',
					success: (modalRes) => {
						if (modalRes.cancel) {
							uni.setClipboardData({
								data: `设备激活失败详情:\n${errorDetail}\n\n完整错误:\n${JSON.stringify(result.error, null, 2)}`,
								success: () => {
									uni.showToast({
										title: '已复制到剪贴板',
										icon: 'success'
									})
								}
							})
						}
					}
				})
			}
		},

		// 测试 OneNET 连接
		async testOneNETConnection() {
			this.addLog('开始测试 OneNET 连接...', 'info')
			
			const config = this.$options.ONE_NET_CONFIG
			const token = config.PRE_GENERATED_TOKEN
			const topic = `$sys/${config.PRODUCT_ID}/${config.DEVICE_NAME}/thing/property/post`
			
			// 构造测试数据
			const testData = {
				id: Date.now().toString(),
				version: '1.0',
				params: {
					heart_rate: {
						value: 75,
						time: Date.now()
					}
				}
			}
			
			const fullUrl = `${config.HTTP_BASE_URL}/device/thing/property/post?topic=${encodeURIComponent(topic)}&protocol=HTTP`
			
			this.addLog(`测试 URL: ${fullUrl.substring(0, 60)}...`, 'info')
			
			uni.request({
				url: fullUrl,
				method: 'POST',
				header: {
					'Content-Type': 'application/json',
					'token': token
				},
				data: testData,
				timeout: 30000,
				success: (res) => {
					console.log('测试连接响应:', res)
					console.log('响应数据:', JSON.stringify(res.data, null, 2))
					
					// 记录完整的响应到日志
					this.addLog(`HTTP 状态码: ${res.statusCode}`, 'info')
					this.addLog(`响应数据类型: ${typeof res.data}`, 'info')
					
					if (res.statusCode === 200) {
						// 检查响应数据
						if (!res.data) {
							uni.showModal({
								title: '连接测试失败',
								content: `❌ 服务器返回空数据`,
								showCancel: false
							})
							this.addLog('✗ 服务器返回空数据', 'error')
							return
						}
						
						// 如果是字符串，尝试解析
						let responseData = res.data
						if (typeof res.data === 'string') {
							try {
								responseData = JSON.parse(res.data)
							} catch (e) {
								uni.showModal({
									title: '连接测试失败',
									content: `❌ 服务器返回非 JSON 数据:\n${res.data.substring(0, 200)}`,
									showCancel: false
								})
								this.addLog('✗ 响应不是有效的 JSON', 'error')
								return
							}
						}
						
						// 检查 code 字段
						if (responseData.code === undefined) {
							const errorDetail = JSON.stringify(responseData, null, 2)
							uni.showModal({
								title: '连接测试失败',
								content: `❌ 服务器返回格式异常:\n${errorDetail.substring(0, 200)}`,
								showCancel: true,
								cancelText: '复制详情',
								confirmText: '确定',
								success: (modalRes) => {
									if (modalRes.cancel) {
										// 复制错误详情到剪贴板
										uni.setClipboardData({
											data: errorDetail,
											success: () => {
												uni.showToast({
													title: '已复制到剪贴板',
													icon: 'success'
												})
											}
										})
									}
								}
							})
							this.addLog('✗ 响应缺少 code 字段', 'error')
							return
						}
						
						if (responseData.code === 0) {
							uni.showModal({
								title: '连接测试成功',
								content: `✅ 成功连接到 OneNET\n\n设备将被激活！`,
								showCancel: false
							})
							this.addLog('✓ 连接测试成功，设备已激活', 'success')
						} else {
							const errorMsg = responseData.msg || '未知错误'
							const fullError = `错误码: ${responseData.code}\n错误信息: ${errorMsg}\n\n完整响应:\n${JSON.stringify(responseData, null, 2)}`
							uni.showModal({
								title: '连接测试失败',
								content: `❌ 错误码: ${responseData.code}\n错误信息: ${errorMsg}`,
								showCancel: true,
								cancelText: '复制详情',
								confirmText: '确定',
								success: (modalRes) => {
									if (modalRes.cancel) {
										uni.setClipboardData({
											data: fullError,
											success: () => {
												uni.showToast({
													title: '已复制到剪贴板',
													icon: 'success'
												})
											}
										})
									}
								}
							})
							this.addLog(`✗ 连接测试失败: [${responseData.code}] ${errorMsg}`, 'error')
						}
					} else {
						uni.showModal({
							title: '连接测试失败',
							content: `❌ HTTP 错误: ${res.statusCode}\n响应: ${JSON.stringify(res.data).substring(0, 200)}`,
							showCancel: false
						})
						this.addLog(`✗ HTTP 错误: ${res.statusCode}`, 'error')
					}
				},
				fail: (err) => {
					console.error('测试连接失败:', err)
					const errorDetail = `网络错误: ${err.errMsg || '无法连接到服务器'}\n\n完整错误:\n${JSON.stringify(err, null, 2)}`
					uni.showModal({
						title: '连接测试失败',
						content: `❌ 网络错误: ${err.errMsg || '无法连接到服务器'}\n\n请检查:\n1. 网络连接是否正常\n2. 是否使用代理/VPN\n3. OneNET 服务是否可用`,
						showCancel: true,
						cancelText: '复制详情',
						confirmText: '确定',
						success: (modalRes) => {
							if (modalRes.cancel) {
								uni.setClipboardData({
									data: errorDetail,
									success: () => {
										uni.showToast({
											title: '已复制到剪贴板',
											icon: 'success'
										})
									}
								})
							}
						}
					})
					this.addLog(`✗ 网络错误: ${err.errMsg}`, 'error')
				}
			})
		},

		// 发送 GET 指令
		sendGetCommand() {
			if (!this.connectedDevice) {
				uni.showToast({
					title: '未连接设备',
					icon: 'none'
				})
				return
			}

			if (!this.characteristicId) {
				uni.showToast({
					title: '无可用写入特征',
					icon: 'none'
				})
				this.addLog('发送 GET 失败: 特征UUID为空', 'error')
				return
			}

			this.addLog('发送 GET 指令...', 'info')
			this.sendStringCommand('GET')
		},

		// 合并多个ArrayBuffer
		mergeArrayBuffers(buffers) {
			const totalLength = buffers.reduce((sum, buf) => sum + buf.byteLength, 0)
			const merged = new Uint8Array(totalLength)
			let offset = 0
			buffers.forEach(buf => {
				merged.set(new Uint8Array(buf), offset)
				offset += buf.byteLength
			})
			return merged.buffer
		},

		disconnectDevice() {
			if (!this.connectedDevice) return

			const deviceName = this.connectedDevice.name || this.connectedDevice.deviceId
			
			this.clearPacketBuffer()
			
			uni.closeBLEConnection({
				deviceId: this.connectedDevice.deviceId,
				success: (res) => {
					this.addLog(`已断开与 ${deviceName} 的连接`, 'info')
					this.connectedDevice = null
					this.connectionStatus = '未连接'
					this.receivedData = ''
					this.receiveList = []
					this.receiveCount = 0
					this.serviceId = ''
					this.characteristicId = ''
					this.notifyCharacteristicId = ''
				},
				fail: (err) => {
					this.addLog('断开连接失败: ' + err.errMsg, 'error')
				}
			})
		},

		sendToDevice() {
			if (!this.sendData || !this.connectedDevice) return
			
			if (!this.characteristicId) {
				uni.showToast({
					title: '无可用写入特征值',
					icon: 'none'
				})
				this.addLog('发送失败: 没有可用的写入特征值', 'error')
				return
			}
			
			this.sendCommand(this.sendData)
			this.sendData = ''
		},

		sendCommand(command) {
			if (!this.connectedDevice) {
				uni.showToast({
					title: '未连接设备',
					icon: 'none'
				})
				return
			}

			if (!this.characteristicId) {
				uni.showToast({
					title: '无可用写入特征',
					icon: 'none'
				})
				this.addLog('发送失败: 特征UUID为空', 'error')
				return
			}

			this.isSending = true
			
			let buffer
			if (this.sendFormat === 'hex') {
				buffer = this.hexToArrayBuffer(command)
				this.addLog(`准备发送十六进制: ${command}`, 'info')
			} else {
				// 使用UTF-8编码发送
				buffer = this.stringToUtf8ArrayBuffer(command)
				this.addLog(`准备发送字符串 (UTF-8): "${command}"`, 'info')
			}

			if (!buffer) {
				this.isSending = false
				uni.showToast({
					title: '数据格式错误',
					icon: 'none'
				})
				return
			}

			const params = {
				deviceId: this.connectedDevice.deviceId,
				serviceId: this.serviceId,
				characteristicId: this.characteristicId,
				value: buffer,
				success: (res) => {
					this.addLog(`写入成功 [特征: ${this.characteristicId}]`, 'success')
					uni.showToast({
						title: '发送成功',
						icon: 'success'
					})
				},
				fail: (err) => {
					this.addLog('写入失败: ' + err.errMsg, 'error')
					uni.showToast({
						title: '发送失败: ' + err.errMsg,
						icon: 'none'
					})
				},
				complete: () => {
					this.isSending = false
				}
			}

			if (this.writeType === 'writeNoResponse') {
				params.type = 'noResponse'
			}

			uni.writeBLECharacteristicValue(params)
		},

		// 同步时间
		syncTime() {
			if (!this.connectedDevice) {
				uni.showToast({
					title: '未连接设备',
					icon: 'none'
				})
				return
			}

			if (!this.characteristicId) {
				uni.showToast({
					title: '无可用写入特征',
					icon: 'none'
				})
				this.addLog('同步时间失败: 特征UUID为空', 'error')
				return
			}

			const now = new Date()
			
			// 获取年份后两位
			const year = now.getFullYear().toString().slice(-2)
			// 月份 (01-12)
			const month = (now.getMonth() + 1).toString().padStart(2, '0')
			// 日期 (01-31)
			const day = now.getDate().toString().padStart(2, '0')
			// 星期 (0-6, 0是周日)
			const week = now.getDay()
			// 小时 (00-23)
			const hour = now.getHours().toString().padStart(2, '0')
			// 分钟 (00-59)
			const minute = now.getMinutes().toString().padStart(2, '0')
			// 秒 (00-59)
			const second = now.getSeconds().toString().padStart(2, '0')
			
			// 格式: $YYMMDDWHHMMSS#
			const timeString = `$${year}${month}${day}${week}${hour}${minute}${second}#`
			
			this.addLog(`准备同步时间: ${timeString}`, 'info')
			this.addLog(`当前时间: ${now.getFullYear()}-${month}-${day} 周${week === 0 ? '日' : week} ${hour}:${minute}:${second}`, 'info')
			
			// 直接使用字符串格式发送（不受sendFormat影响）
			this.sendStringCommand(timeString)
		},

		// 发送字符串命令（固定使用UTF-8，不受sendFormat影响）
		sendStringCommand(command) {
			this.isSending = true
			
			// 直接使用UTF-8编码发送字符串
			const buffer = this.stringToUtf8ArrayBuffer(command)
			const hexString = this.arrayBufferToHex(buffer)
			
			this.addLog(`发送字符串: "${command}"`, 'info')
			this.addLog(`字符串长度: ${command.length} 字符`, 'info')
			this.addLog(`UTF-8字节数: ${buffer.byteLength} 字节`, 'info')
			this.addLog(`HEX数据: ${hexString}`, 'info')

			if (!buffer) {
				this.isSending = false
				uni.showToast({
					title: '数据编码错误',
					icon: 'none'
				})
				return
			}

			const params = {
				deviceId: this.connectedDevice.deviceId,
				serviceId: this.serviceId,
				characteristicId: this.characteristicId,
				value: buffer,
				success: (res) => {
					this.addLog(`写入成功 [特征: ${this.characteristicId}]`, 'success')
					uni.showToast({
						title: '发送成功',
						icon: 'success'
					})
				},
				fail: (err) => {
					this.addLog('写入失败: ' + err.errMsg, 'error')
					uni.showToast({
						title: '发送失败: ' + err.errMsg,
						icon: 'none'
					})
				},
				complete: () => {
					this.isSending = false
				}
			}

			if (this.writeType === 'writeNoResponse') {
				params.type = 'noResponse'
			}

			uni.writeBLECharacteristicValue(params)
		},

		// 解码Buffer为字符串（支持多种编码）
		decodeBuffer(buffer, encoding) {
			try {
				const uint8Array = new Uint8Array(buffer)
				
				switch (encoding) {
					case 'UTF-8':
						return this.utf8Decoder(uint8Array)
					case 'ASCII':
						return this.asciiDecoder(uint8Array)
					case 'GBK':
					case 'GB2312':
					case 'GB18030':
						// 中文编码简化处理
						return this.gbkDecoder(uint8Array)
					case 'Unicode':
						return this.unicodeDecoder(uint8Array)
					case 'Hex':
						return this.arrayBufferToHex(buffer)
					default:
						return this.utf8Decoder(uint8Array)
				}
			} catch (e) {
				return '[解码失败]'
			}
		},

		// UTF-8解码器
		utf8Decoder(uint8Array) {
			try {
				const decoder = new TextDecoder('utf-8')
				return decoder.decode(uint8Array)
			} catch (e) {
				// 手动解码
				let str = ''
				let i = 0
				while (i < uint8Array.length) {
					const byte = uint8Array[i]
					if (byte < 0x80) {
						str += String.fromCharCode(byte)
						i++
					} else if ((byte & 0xE0) === 0xC0) {
						const charCode = ((byte & 0x1F) << 6) | (uint8Array[i + 1] & 0x3F)
						str += String.fromCharCode(charCode)
						i += 2
					} else if ((byte & 0xF0) === 0xE0) {
						const charCode = ((byte & 0x0F) << 12) | 
										 ((uint8Array[i + 1] & 0x3F) << 6) | 
										 (uint8Array[i + 2] & 0x3F)
						str += String.fromCharCode(charCode)
						i += 3
					} else {
						str += String.fromCharCode(byte)
						i++
					}
				}
				return str
			}
		},

		// ASCII解码器
		asciiDecoder(uint8Array) {
			let str = ''
			for (let i = 0; i < uint8Array.length; i++) {
				const char = uint8Array[i]
				if (char >= 32 && char <= 126) {
					str += String.fromCharCode(char)
				} else {
					str += '.'
				}
			}
			return str
		},

		// GBK/GB2312/GB18030解码器（简化版）
		gbkDecoder(uint8Array) {
			// 使用UTF-8解码作为近似，实际GBK解码需要完整的码表
			// 这里提供一个简化的中文字符处理
			try {
				const decoder = new TextDecoder('gbk')
				return decoder.decode(uint8Array)
			} catch (e) {
				// 如果浏览器不支持GBK，尝试UTF-8
				return this.utf8Decoder(uint8Array)
			}
		},

		// Unicode解码器
		unicodeDecoder(uint8Array) {
			let str = ''
			for (let i = 0; i < uint8Array.length; i += 2) {
				const charCode = (uint8Array[i] << 8) | uint8Array[i + 1]
				str += String.fromCharCode(charCode)
			}
			return str
		},

		arrayBufferToHex(buffer) {
			const uint8Array = new Uint8Array(buffer)
			return Array.from(uint8Array)
				.map(b => b.toString(16).padStart(2, '0').toUpperCase())
				.join(' ')
		},

		// 字符串转UTF-8 ArrayBuffer
		stringToUtf8ArrayBuffer(str) {
			try {
				const encoder = new TextEncoder()
				const uint8Array = encoder.encode(str)
				return uint8Array.buffer
			} catch (e) {
				// 手动编码
				const utf8 = []
				for (let i = 0; i < str.length; i++) {
					let charcode = str.charCodeAt(i)
					if (charcode < 0x80) {
						utf8.push(charcode)
					} else if (charcode < 0x800) {
						utf8.push(0xc0 | (charcode >> 6), 
								  0x80 | (charcode & 0x3f))
					} else if (charcode < 0xd800 || charcode >= 0xe000) {
						utf8.push(0xe0 | (charcode >> 12), 
								  0x80 | ((charcode >> 6) & 0x3f), 
								  0x80 | (charcode & 0x3f))
					} else {
						i++
						charcode = ((charcode & 0x3ff) << 10) | (str.charCodeAt(i) & 0x3ff)
						utf8.push(0xf0 | (charcode >> 18), 
								  0x80 | ((charcode >> 12) & 0x3f), 
								  0x80 | ((charcode >> 6) & 0x3f), 
								  0x80 | (charcode & 0x3f))
					}
				}
				const buffer = new ArrayBuffer(utf8.length)
				const dataView = new DataView(buffer)
				for (let i = 0; i < utf8.length; i++) {
					dataView.setUint8(i, utf8[i])
				}
				return buffer
			}
		},

		hexToArrayBuffer(hexString) {
			try {
				const hex = hexString.replace(/\s+/g, '')
				if (!/^[0-9A-Fa-f]*$/.test(hex)) {
					return null
				}
				
				const buffer = new ArrayBuffer(hex.length / 2)
				const dataView = new DataView(buffer)
				for (let i = 0; i < hex.length; i += 2) {
					dataView.setUint8(i / 2, parseInt(hex.substr(i, 2), 16))
				}
				return buffer
			} catch (e) {
				return null
			}
		}
	}
}
</script>

<style>
.container {
	padding: 20rpx;
	background-color: #f5f5f5;
	min-height: 100vh;
}

.status-bar {
	display: flex;
	justify-content: space-around;
	background-color: #fff;
	padding: 20rpx;
	border-radius: 16rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

.status-item {
	display: flex;
	align-items: center;
}

.status-label {
	font-size: 28rpx;
	color: #666;
	margin-right: 10rpx;
}

.status-value {
	font-size: 28rpx;
	font-weight: bold;
}

.status-value.enabled {
	color: #07c160;
}

.status-value.disabled {
	color: #999;
}

.status-value.connected {
	color: #07c160;
}

.status-value.disconnected {
	color: #ff4d4f;
}

.action-section {
	display: flex;
	justify-content: center;
	gap: 20rpx;
	margin-bottom: 20rpx;
}

.btn-primary {
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	color: #fff;
	font-size: 30rpx;
	padding: 20rpx 50rpx;
	border-radius: 40rpx;
	border: none;
	box-shadow: 0 4rpx 15rpx rgba(102, 126, 234, 0.4);
}

.btn-primary[disabled] {
	opacity: 0.6;
}

.btn-secondary {
	background-color: #fff;
	color: #666;
	font-size: 30rpx;
	padding: 20rpx 40rpx;
	border-radius: 40rpx;
	border: 2rpx solid #ddd;
}

.btn-danger {
	background-color: #ff4d4f;
	color: #fff;
	font-size: 30rpx;
	padding: 20rpx 40rpx;
	border-radius: 40rpx;
	border: none;
}

.device-section {
	background-color: #fff;
	border-radius: 16rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

/* OneNET 云平台样式 */
.onenet-section {
	background: linear-gradient(135deg, #07c160 0%, #10b981 100%);
	border-radius: 16rpx;
	padding: 25rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 4rpx 15rpx rgba(7, 193, 96, 0.3);
}

.onenet-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 20rpx;
}

.onenet-title {
	font-size: 32rpx;
	font-weight: bold;
	color: #fff;
}

.onenet-status {
	font-size: 24rpx;
	color: rgba(255, 255, 255, 0.8);
}

.onenet-status.uploaded {
	color: #fff;
	font-weight: bold;
}

.onenet-actions {
	display: flex;
	gap: 15rpx;
}

.btn-onenet {
	flex: 1;
	background-color: #fff;
	color: #07c160;
	font-size: 28rpx;
	padding: 20rpx 30rpx;
	border-radius: 30rpx;
	border: none;
	font-weight: bold;
}

.btn-onenet[disabled] {
	opacity: 0.6;
}

.btn-onenet-secondary {
	background-color: rgba(255, 255, 255, 0.2);
	color: #fff;
	font-size: 26rpx;
	padding: 20rpx 30rpx;
	border-radius: 30rpx;
	border: 2rpx solid rgba(255, 255, 255, 0.5);
}

.onenet-config-check {
	margin-top: 15rpx;
	text-align: center;
}

.config-check-link {
	font-size: 24rpx;
	color: rgba(255, 255, 255, 0.9);
	text-decoration: underline;
}

/* 上传模式选择 */
.onenet-mode-select {
	margin: 15rpx 0;
	display: flex;
	align-items: center;
	gap: 15rpx;
}

.mode-label {
	font-size: 26rpx;
	color: rgba(255, 255, 255, 0.9);
}

.mode-options {
	display: flex;
	gap: 10rpx;
	flex: 1;
}

.mode-option {
	flex: 1;
	padding: 10rpx 15rpx;
	background-color: rgba(255, 255, 255, 0.2);
	border-radius: 20rpx;
	font-size: 24rpx;
	color: rgba(255, 255, 255, 0.8);
	text-align: center;
	border: 2rpx solid transparent;
}

.mode-option.active {
	background-color: #fff;
	color: #07c160;
	border-color: #fff;
	font-weight: bold;
}

/* OneNET 警告提示 */
.onenet-warning {
	background-color: #fffbe6;
	border: 2rpx solid #ffe58f;
	border-radius: 16rpx;
	padding: 20rpx;
	margin: 20rpx;
	text-align: center;
}

.warning-text {
	font-size: 28rpx;
	color: #d48806;
}

/* 历史数据入口样式 */
.history-entry-section {
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	border-radius: 16rpx;
	padding: 30rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 4rpx 15rpx rgba(102, 126, 234, 0.3);
}

.history-entry-content {
	display: flex;
	align-items: center;
	gap: 20rpx;
}

.history-entry-icon {
	width: 80rpx;
	height: 80rpx;
	background-color: rgba(255, 255, 255, 0.2);
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
}

.icon-text {
	font-size: 40rpx;
}

.history-entry-info {
	flex: 1;
	display: flex;
	flex-direction: column;
}

.history-entry-title {
	font-size: 32rpx;
	font-weight: bold;
	color: #fff;
}

.history-entry-desc {
	font-size: 24rpx;
	color: rgba(255, 255, 255, 0.8);
	margin-top: 5rpx;
}

.history-entry-arrow {
	font-size: 36rpx;
	color: #fff;
	font-weight: bold;
}

.section-title {
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 32rpx;
	font-weight: bold;
	color: #333;
	margin-bottom: 20rpx;
	padding-bottom: 15rpx;
	border-bottom: 2rpx solid #f0f0f0;
}

.clear-log {
	font-size: 26rpx;
	color: #667eea;
	font-weight: normal;
}

.log-actions {
	display: flex;
	gap: 20rpx;
}

.copy-log-btn {
	font-size: 26rpx;
	color: #07c160;
	font-weight: normal;
}

.data-stats {
	font-size: 24rpx;
	color: #667eea;
	font-weight: normal;
}

.device-list {
	max-height: 400rpx;
}

.device-item {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 20rpx;
	border-bottom: 2rpx solid #f5f5f5;
	background-color: #fafafa;
	border-radius: 12rpx;
	margin-bottom: 15rpx;
}

.device-item.connected {
	background-color: #e6f7ff;
	border: 2rpx solid #1890ff;
}

.device-item.history-device {
	background-color: #fff7e6;
	border: 2rpx solid #ffa940;
}

.device-time {
	font-size: 22rpx;
	color: #ffa940;
}

.clear-history {
	font-size: 26rpx;
	color: #ff4d4f;
	font-weight: normal;
}

.device-info {
	flex: 1;
	display: flex;
	flex-direction: column;
}

.device-name {
	font-size: 30rpx;
	color: #333;
	font-weight: bold;
	margin-bottom: 8rpx;
}

.device-id {
	font-size: 22rpx;
	color: #999;
	margin-bottom: 5rpx;
}

.device-rssi {
	font-size: 24rpx;
	color: #07c160;
}

.device-action {
	padding-left: 20rpx;
}

.connect-text {
	font-size: 26rpx;
	color: #667eea;
}

.empty-tip {
	text-align: center;
	padding: 40rpx;
	color: #999;
	font-size: 28rpx;
}

.info-section {
	background-color: #fff;
	border-radius: 16rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

.info-item {
	display: flex;
	padding: 10rpx 0;
	border-bottom: 1rpx solid #f0f0f0;
}

.info-item:last-child {
	border-bottom: none;
}

.info-label {
	font-size: 26rpx;
	color: #666;
	min-width: 150rpx;
}

.info-value {
	font-size: 24rpx;
	color: #333;
	flex: 1;
	word-break: break-all;
}

.data-section {
	background-color: #fff;
	border-radius: 16rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

/* 数据包配置 */
.packet-config {
	background-color: #f9f9f9;
	border-radius: 12rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
}

.config-row {
	display: flex;
	align-items: center;
	gap: 15rpx;
	margin-bottom: 15rpx;
}

.config-row:last-child {
	margin-bottom: 0;
}

.config-label {
	font-size: 26rpx;
	color: #666;
	min-width: 140rpx;
}

.config-input {
	background-color: #fff;
	border-radius: 8rpx;
	padding: 10rpx 20rpx;
	font-size: 26rpx;
	width: 150rpx;
}

.timeout-input {
	width: 100rpx;
}

.config-hint {
	font-size: 24rpx;
	color: #999;
}

.data-display {
	margin-bottom: 20rpx;
}

.data-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 10rpx;
	flex-wrap: wrap;
	gap: 10rpx;
}

.data-label {
	font-size: 28rpx;
	color: #666;
}

.format-controls {
	display: flex;
	align-items: center;
	gap: 20rpx;
}

.copy-btn {
	font-size: 24rpx;
	color: #667eea;
	background-color: #f0f0f0;
	padding: 8rpx 20rpx;
	border-radius: 20rpx;
}

.encoding-select {
	display: flex;
	align-items: center;
	gap: 10rpx;
}

.select-label {
	font-size: 24rpx;
	color: #666;
}

.picker {
	background-color: #f0f0f0;
	padding: 8rpx 20rpx;
	border-radius: 20rpx;
}

.picker-value {
	font-size: 24rpx;
	color: #333;
}

.format-toggle {
	display: flex;
	gap: 10rpx;
}

.toggle-item {
	font-size: 24rpx;
	padding: 8rpx 16rpx;
	border-radius: 20rpx;
	background-color: #f0f0f0;
	color: #666;
}

.toggle-item.active {
	background-color: #667eea;
	color: #fff;
}

.receive-box {
	background-color: #f5f5f5;
	border-radius: 12rpx;
	padding: 20rpx;
	min-height: 200rpx;
	max-height: 400rpx;
}

.empty-receive {
	text-align: center;
	padding: 40rpx;
	color: #999;
	font-size: 28rpx;
}

.receive-item {
	padding: 15rpx;
	border-bottom: 2rpx solid #e0e0e0;
	border-radius: 8rpx;
	margin-bottom: 10rpx;
}

.receive-item:last-child {
	border-bottom: none;
	margin-bottom: 0;
}

.merged-packet {
	background-color: #e6f7ff;
	border-left: 4rpx solid #1890ff;
}

.raw-packet {
	background-color: #fff;
}

.packet-header {
	display: flex;
	align-items: center;
	gap: 15rpx;
	margin-bottom: 8rpx;
	flex-wrap: wrap;
}

.receive-time {
	font-size: 22rpx;
	color: #999;
}

.packet-type {
	font-size: 20rpx;
	color: #1890ff;
	background-color: #e6f7ff;
	padding: 4rpx 12rpx;
	border-radius: 10rpx;
}

.packet-type.raw {
	color: #666;
	background-color: #f0f0f0;
}

.packet-size {
	font-size: 20rpx;
	color: #07c160;
}

.packet-count {
	font-size: 20rpx;
	color: #ff9800;
}

.receive-content {
	font-size: 28rpx;
	color: #333;
	word-break: break-all;
}

.receive-hex {
	font-size: 22rpx;
	color: #667eea;
	margin-top: 5rpx;
	display: block;
}

/* 可选择文本样式 */
.selectable {
	user-select: text;
	-webkit-user-select: text;
}

.send-section {
	margin-bottom: 20rpx;
}

.send-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 10rpx;
}

.send-label {
	font-size: 26rpx;
	color: #666;
}

.send-input-area {
	display: flex;
	gap: 15rpx;
}

.send-input {
	flex: 1;
	background-color: #f5f5f5;
	border-radius: 12rpx;
	padding: 20rpx;
	font-size: 28rpx;
}

.btn-send {
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	color: #fff;
	font-size: 28rpx;
	padding: 0 40rpx;
	border-radius: 12rpx;
	border: none;
}

.btn-send[disabled] {
	opacity: 0.6;
}

.time-sync-section {
	display: flex;
	align-items: center;
	gap: 15rpx;
	margin-top: 20rpx;
	padding-top: 20rpx;
	border-top: 2rpx solid #f0f0f0;
}

.sync-label {
	font-size: 26rpx;
	color: #666;
}

.btn-sync {
	background: linear-gradient(135deg, #07c160 0%, #10b981 100%);
	color: #fff;
	font-size: 26rpx;
	padding: 15rpx 40rpx;
	border-radius: 30rpx;
	border: none;
}

.sync-format {
	font-size: 22rpx;
	color: #999;
}

.history-section {
	display: flex;
	align-items: center;
	gap: 15rpx;
	margin-top: 20rpx;
	padding-top: 20rpx;
	border-top: 2rpx solid #f0f0f0;
}

.history-label {
	font-size: 26rpx;
	color: #666;
}

.btn-history {
	background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
	color: #fff;
	font-size: 26rpx;
	padding: 15rpx 40rpx;
	border-radius: 30rpx;
	border: none;
}

.command-section {
	display: flex;
	align-items: center;
	gap: 15rpx;
	margin-top: 20rpx;
	padding-top: 20rpx;
	border-top: 2rpx solid #f0f0f0;
}

.command-label {
	font-size: 26rpx;
	color: #666;
}

.btn-get {
	background: linear-gradient(135deg, #ff9800 0%, #ff5722 100%);
	color: #fff;
	font-size: 26rpx;
	padding: 15rpx 40rpx;
	border-radius: 30rpx;
	border: none;
}

.log-section {
	background-color: #fff;
	border-radius: 16rpx;
	padding: 20rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}

.log-box {
	max-height: 300rpx;
	background-color: #1e1e1e;
	border-radius: 12rpx;
	padding: 15rpx;
}

.log-item {
	padding: 10rpx 0;
	border-bottom: 1rpx solid #333;
}

.log-time {
	color: #888;
	font-size: 22rpx;
	margin-right: 15rpx;
}

.log-content {
	font-size: 24rpx;
	word-break: break-all;
}

.log-content.success {
	color: #4caf50;
}

.log-content.error {
	color: #f44336;
}

.log-content.info {
	color: #fff;
}
</style>
