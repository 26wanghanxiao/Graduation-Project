# OneNET Token 生成脚本 (PowerShell)

# 配置信息
$productId = 'fQ88v8SIm9'
$deviceName = 'HealthDevice001'
$deviceSecret = 'TWVvTTRycmhQdVl0RlpjS2JrdXBjVUZpSzRweVRWemI='

# 参数
$version = '2018-10-31'
$method = 'sha1'
$res = "products/$productId/devices/$deviceName"

# 生成 100 年后的过期时间
$expireTime = [int]([DateTimeOffset]::UtcNow.AddYears(100).ToUnixTimeSeconds())

Write-Host "========== OneNET Token 生成工具 ==========" -ForegroundColor Cyan
Write-Host ""
Write-Host "产品ID: $productId"
Write-Host "设备名称: $deviceName"
Write-Host "过期时间: $(Get-Date -UnixTimeSeconds $expireTime)"
Write-Host ""

# 构造签名字符串
$stringForSignature = "$expireTime`n$method`n$res`n$version"
Write-Host "签名字符串:"
Write-Host $stringForSignature
Write-Host ""

# Base64 解码密钥
$keyBytes = [Convert]::FromBase64String($deviceSecret)
$key = [System.Text.Encoding]::UTF8.GetString($keyBytes)
Write-Host "解码后的密钥: $key"
Write-Host ""

# HMAC-SHA1 签名
$hmac = New-Object System.Security.Cryptography.HMACSHA1
$hmac.Key = $keyBytes
$signatureBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($stringForSignature))
$signature = [Convert]::ToBase64String($signatureBytes)

Write-Host "签名结果: $signature"
Write-Host ""

# URL 编码函数
function UrlEncode($str) {
    return [System.Web.HttpUtility]::UrlEncode($str)
}

# 构造 Token
$tokenParams = @{
    'version' = $version
    'res' = $res
    'et' = $expireTime.ToString()
    'method' = $method
    'sign' = $signature
}

$tokenParts = @()
foreach ($param in $tokenParams.GetEnumerator()) {
    $encodedValue = UrlEncode $param.Value
    $tokenParts += "$($param.Key)=$encodedValue"
}

$token = $tokenParts -join '&'

Write-Host "100年有效期 Token:" -ForegroundColor Green
Write-Host $token -ForegroundColor Yellow
Write-Host ""
Write-Host "请将上述 Token 复制到 config/onenet.js 的 PRE_GENERATED_TOKEN 字段中" -ForegroundColor Cyan

# 同时保存到文件
$token | Out-File -FilePath "generated-token.txt" -Encoding UTF8
Write-Host "Token 已保存到 generated-token.txt 文件"
