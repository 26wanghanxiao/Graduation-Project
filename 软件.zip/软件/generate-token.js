/**
 * OneNET Token 生成脚本
 * 使用 Web Crypto API 生成 Token
 */

// 你的配置信息
const config = {
	productId: 'fQ88v8SIm9',
	deviceName: 'HealthDevice001',
	deviceSecret: 'TWVvTTRycmhQdVl0RlpjS2JrdXBjVUZpSzRweVRWemI='
}

/**
 * Base64 解码
 */
function base64Decode(str) {
	const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
	let output = ''
	let i = 0
	
	str = String(str).replace(/[^A-Za-z0-9+/=]/g, '')
	
	while (i < str.length) {
		const enc1 = chars.indexOf(str.charAt(i++))
		const enc2 = chars.indexOf(str.charAt(i++))
		const enc3 = chars.indexOf(str.charAt(i++))
		const enc4 = chars.indexOf(str.charAt(i++))
		
		const chr1 = (enc1 << 2) | (enc2 >> 4)
		const chr2 = ((enc2 & 15) << 4) | (enc3 >> 2)
		const chr3 = ((enc3 & 3) << 6) | enc4
		
		output += String.fromCharCode(chr1)
		if (enc3 !== 64) output += String.fromCharCode(chr2)
		if (enc4 !== 64) output += String.fromCharCode(chr3)
	}
	
	return output
}

/**
 * HMAC-SHA1 签名
 */
async function hmacSha1(message, secret) {
	// 将字符串转换为 Uint8Array
	const encoder = new TextEncoder()
	const messageData = encoder.encode(message)
	const secretData = encoder.encode(secret)
	
	// 导入密钥
	const cryptoKey = await crypto.subtle.importKey(
		'raw',
		secretData,
		{ name: 'HMAC', hash: 'SHA-1' },
		false,
		['sign']
	)
	
	// 签名
	const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData)
	
	// 转换为 Base64
	const signatureArray = new Uint8Array(signature)
	let binary = ''
	for (let i = 0; i < signatureArray.byteLength; i++) {
		binary += String.fromCharCode(signatureArray[i])
	}
	return btoa(binary)
}

/**
 * URL 编码
 */
function urlEncode(str) {
	return encodeURIComponent(str)
		.replace(/%20/g, '+')
		.replace(/%2F/g, '%2F')
		.replace(/%3D/g, '%2F')
		.replace(/%26/g, '%26')
}

/**
 * 生成 Token
 */
async function generateToken(expireTime) {
	const version = '2018-10-31'
	const method = 'sha1'
	const res = `products/${config.productId}/devices/${config.deviceName}`
	
	// 构造签名字符串
	const stringForSignature = `${expireTime}\n${method}\n${res}\n${version}`
	
	console.log('签名字符串:', stringForSignature)
	console.log('')
	
	// 解码密钥
	const key = base64Decode(config.deviceSecret)
	console.log('解码后的密钥:', key)
	console.log('')
	
	// HMAC-SHA1 签名
	const signature = await hmacSha1(stringForSignature, key)
	console.log('签名结果:', signature)
	console.log('')
	
	// 构造 Token 参数
	const params = {
		version: version,
		res: res,
		et: expireTime.toString(),
		method: method,
		sign: signature
	}
	
	// URL 编码并拼接
	const tokenParts = []
	for (const [key, value] of Object.entries(params)) {
		tokenParts.push(`${key}=${urlEncode(value)}`)
	}
	
	return tokenParts.join('&')
}

/**
 * 主函数
 */
async function main() {
	console.log('========== OneNET Token 生成工具 ==========\n')
	console.log('产品ID:', config.productId)
	console.log('设备名称:', config.deviceName)
	console.log('设备密钥:', config.deviceSecret.substring(0, 10) + '...')
	console.log('')
	
	// 生成 100 年有效期的 Token
	const expireTime100Years = Math.floor(Date.now() / 1000) + 100 * 365 * 24 * 60 * 60
	console.log('过期时间戳:', expireTime100Years)
	console.log('过期日期:', new Date(expireTime100Years * 1000).toLocaleString())
	console.log('')
	
	try {
		const token100Years = await generateToken(expireTime100Years)
		console.log('100年有效期 Token:')
		console.log(token100Years)
		console.log('')
		console.log('请将上述 Token 复制到 config/onenet.js 的 PRE_GENERATED_TOKEN 字段中')
	} catch (error) {
		console.error('生成失败:', error)
	}
}

// 运行
main()
