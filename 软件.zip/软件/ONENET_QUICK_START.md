# OneNET 快速配置指南

## 🚀 三步完成配置

### 第一步：获取 OneNET 平台信息（5分钟）

1. 登录 [OneNET 控制台](https://open.iot.10086.cn/)
2. 进入你的产品详情页
3. 记录以下信息：
   - **ProductID**（产品ID）：如 `a1b2c3d4e5`
   - **DeviceName**（设备名称）：如 `HealthDevice001`
   - **DeviceSecret**（设备密钥）：如 `d2VzdGFkYXRhMTIzNA==`

### 第二步：生成 Token（2分钟）

#### 方法 A：使用 Token 生成工具（推荐）

1. 确保已安装 Node.js
2. 打开 `utils/token-generator.js`
3. 修改第 113-117 行的配置：

```javascript
const config = {
    productId: 'a1b2c3d4e5',              // 替换为你的 ProductID
    deviceName: 'HealthDevice001',        // 替换为你的 DeviceName
    deviceSecret: 'd2VzdGFkYXRhMTIzNA=='  // 替换为你的 DeviceSecret
}
```

4. 打开命令行，进入项目目录：
```bash
cd c:\Users\wang\Desktop\蓝牙\Bluetooth
```

5. 运行生成工具：
```bash
node utils/token-generator.js
```

6. 复制输出的 **100年有效期 Token**

#### 方法 B：使用 OneNET 官方工具

1. 下载 [Token 生成工具](https://open.iot.10086.cn/doc/iot_platform/book/device-connect&manager/device-auth.html)
2. 填写参数：
   - version: `2018-10-31`
   - res: `products/{ProductID}/devices/{DeviceName}`
   - et: 未来时间戳（如 4765363200 表示 2121年）
   - method: `sha1`
   - key: 你的 DeviceSecret
3. 点击生成，复制 Token

### 第三步：配置项目（1分钟）

1. 打开 `config/onenet.js`
2. 填入你的信息：

```javascript
const ONE_NET_CONFIG = {
    HTTP_BASE_URL: 'https://open.iot.10086.cn/studio/http',
    PRODUCT_ID: 'a1b2c3d4e5',              // 替换
    DEVICE_NAME: 'HealthDevice001',        // 替换
    DEVICE_SECRET: 'd2VzdGFkYXRhMTIzNA==', // 替换
    PRE_GENERATED_TOKEN: 'version=2018-10-31&res=products%2Fa1b2c3d4e5%2Fdevices%2FHealthDevice001&et=4765363200&method=sha1&sign=...' // 替换
}
```

3. 保存文件

## ✅ 验证配置

### 方法 1：使用配置检查工具

```bash
node utils/onenet-config-checker.js
```

会看到如下输出：
```
========== OneNET 配置检查 ==========

✅ PRODUCT_ID: a1b2c3d4e5
✅ DEVICE_NAME: HealthDevice001
✅ DEVICE_SECRET: d2Vz****1234
✅ PRE_GENERATED_TOKEN: vers****abcd
   Token 信息:
   - 版本: 2018-10-31
   - 资源: products/a1b2c3d4e5/devices/HealthDevice001
   - 过期时间: 2121/1/1 00:00:00
   - 签名方法: sha1
   - 剩余有效期: 35243 天

========== 检查结果 ==========

✅ 配置检查通过，可以正常使用 OneNET 功能
```

### 方法 2：在 APP 中测试

1. 打开 APP
2. 确保有历史数据（通过蓝牙采集或已有数据）
3. 点击首页"上传数据"按钮
4. 查看日志输出，确认上传成功

## 📱 使用功能

### 上传数据到云端

1. 在 APP 首页找到 **"OneNET 云平台"** 区域
2. 点击 **"上传数据 (X条)"** 按钮
3. 等待上传完成
4. 成功后会显示：**"成功上传 X 条数据"**

### 查看云端数据

1. 点击 **"查看云端数据"** 按钮
2. 链接复制到剪贴板
3. 在浏览器中打开 OneNET 控制台
4. 或使用格式：
```
https://open.iot.10086.cn/studio/device/{ProductID}/device/{DeviceName}/detail
```

## 🔧 故障排除

### 问题 1：提示"请先在 config/onenet.js 中配置 PRE_GENERATED_TOKEN"

**原因**：Token 未配置或配置错误

**解决**：
1. 重新运行 `node utils/token-generator.js`
2. 复制生成的 Token
3. 粘贴到 `config/onenet.js` 的 `PRE_GENERATED_TOKEN` 字段

### 问题 2：上传失败，提示"鉴权失败"

**原因**：Token 过期或信息不匹配

**解决**：
1. 检查 ProductID、DeviceName 是否正确
2. 重新生成 Token（确保 et 时间是未来时间）
3. 更新配置文件

### 问题 3：上传成功但平台看不到数据

**原因**：物模型未配置或数据格式不匹配

**解决**：
1. 在 OneNET 平台配置物模型（heart_rate, blood_oxygen, steps, distance）
2. 检查数据流是否正确创建
3. 在"物模型数据"页面查看

## 📋 配置检查清单

- [ ] 已注册 OneNET 账号
- [ ] 已创建产品和设备
- [ ] 已记录 ProductID、DeviceName、DeviceSecret
- [ ] 已生成 Token（有效期足够长）
- [ ] 已配置 `config/onenet.js`
- [ ] 已验证配置（运行检查工具或通过）
- [ ] 已测试数据上传功能

## 📞 需要帮助？

- OneNET 官方文档：https://open.iot.10086.cn/doc/iot_platform/book/introduce/index.html
- API 调试工具：https://open.iot.10086.cn/console/monitor/apiDebug
- 查看详细文档：[ONENET_SETUP_GUIDE.md](./ONENET_SETUP_GUIDE.md)

---

**完成以上步骤后，你的 APP 就可以将历史数据上传到 OneNET 云平台了！**
