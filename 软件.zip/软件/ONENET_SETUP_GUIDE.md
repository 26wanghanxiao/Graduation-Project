# OneNET 云平台接入完整操作指南

## 📋 目录
1. [平台注册与配置](#一平台注册与配置)
2. [Token 生成](#二token-生成)
3. [代码配置](#三代码配置)
4. [功能使用](#四功能使用)
5. [常见问题](#五常见问题)

---

## 一、平台注册与配置

### 1.1 注册 OneNET 账号

1. 访问 OneNET 官网：https://open.iot.10086.cn/
2. 点击右上角"立即注册"
3. 填写注册信息（手机号/邮箱）
4. 完成实名认证（个人认证即可）

### 1.2 创建产品

1. 登录 OneNET 控制台
2. 点击左侧菜单"产品管理"
3. 点击"创建产品"按钮
4. 填写产品信息：

| 参数 | 填写值 | 说明 |
|------|--------|------|
| 产品名称 | 蓝牙健康监测 | 自定义名称 |
| 产品类型 | 标准产品 | 默认选项 |
| 节点类型 | 直连设备 | 设备直接连接平台 |
| 接入协议 | HTTP | 推荐，简单易用 |
| 数据协议 | OneJSON | 平台标准格式 |
| 联网方式 | 其他 | 通过蓝牙网关 |

5. 点击"确定"创建产品

### 1.3 记录产品 ID

创建成功后，进入产品详情页，记录 **ProductID**（产品ID），格式如：`a1b2c3d4e5`

### 1.4 创建设备

1. 在产品详情页，点击"设备管理"
2. 点击"添加设备"按钮
3. 填写设备信息：

| 参数 | 填写值 |
|------|--------|
| 设备名称 | HealthDevice001 |
| 描述 | 蓝牙健康监测设备 |

4. 点击"确定"创建设备

### 1.5 获取设备密钥

创建设备后，在设备列表中：
1. 找到刚创建的设备
2. 点击"查看"进入设备详情
3. 记录以下信息：
   - **DeviceName**（设备名称）：如 `HealthDevice001`
   - **DeviceSecret**（设备密钥）：如 `d2VzdGFkYXRhMTIzNA==`

⚠️ **重要**：设备密钥只显示一次，请务必保存好！

---

## 二、Token 生成

由于小程序环境无法直接生成 Token，需要在 Node.js 环境生成。

### 2.1 安装 Node.js

1. 访问 https://nodejs.org/
2. 下载 LTS 版本（长期支持版）
3. 按提示完成安装

### 2.2 生成 Token

#### 方法一：使用提供的工具（推荐）

1. 打开文件 `utils/token-generator.js`
2. 修改配置信息（第 115-119 行）：

```javascript
const config = {
    productId: 'a1b2c3d4e5',      // 替换为你的产品ID
    deviceName: 'HealthDevice001', // 替换为你的设备名称
    deviceSecret: 'd2VzdGFkYXRhMTIzNA==' // 替换为你的设备密钥
}
```

3. 打开命令行，进入项目目录：
```bash
cd c:\Users\wang\Desktop\蓝牙\Bluetooth
```

4. 运行生成工具：
```bash
node utils/token-generator.js
```

5. 复制生成的 Token（100年有效期版本）

#### 方法二：使用 OneNET 官方工具

1. 下载官方 Token 生成工具：https://open.iot.10086.cn/doc/iot_platform/book/device-connect&manager/device-auth.html
2. 填写参数：
   - version: `2018-10-31`
   - res: `products/{产品ID}/devices/{设备名称}`
   - et: 过期时间戳（可使用 https://tool.lu/timestamp/ 生成）
   - method: `sha1`
   - key: 设备密钥
3. 点击生成，复制 Token

---

## 三、代码配置

### 3.1 配置产品信息

打开文件 `config/onenet.js`，填写以下信息：

```javascript
const ONE_NET_CONFIG = {
    HTTP_BASE_URL: 'https://open.iot.10086.cn/studio/http',
    
    // 替换为你的产品ID
    PRODUCT_ID: 'a1b2c3d4e5',
    
    // 替换为你的设备名称
    DEVICE_NAME: 'HealthDevice001',
    
    // 替换为你的设备密钥
    DEVICE_SECRET: 'd2VzdGFkYXRhMTIzNA==',
    
    // 粘贴生成的 Token
    PRE_GENERATED_TOKEN: 'version=2018-10-31&res=products%2Fa1b2c3d4e5%2Fdevices%2FHealthDevice001&et=...'
}
```

### 3.2 配置物模型（可选）

为了让数据在平台正确显示，建议配置物模型：

1. 进入产品详情页
2. 点击"物模型"
3. 点击"编辑"
4. 添加以下属性：

| 属性名称 | 标识符 | 数据类型 | 取值范围 | 单位 |
|---------|--------|---------|---------|------|
| 心率 | heart_rate | 整数 | 0-200 | bpm |
| 血氧 | blood_oxygen | 整数 | 0-100 | % |
| 步数 | steps | 整数 | 0-999999 | 步 |
| 距离 | distance | 整数 | 0-99999 | 米 |

5. 点击"保存"

---

## 四、功能使用

### 4.1 上传数据到 OneNET

1. 打开 APP，确保已有历史数据（通过蓝牙设备采集或已有数据）
2. 在首页找到"OneNET 云平台"区域
3. 点击"上传数据 (X条)"按钮
4. 等待上传完成，显示"上传成功"提示

### 4.2 查看云端数据

1. 点击"查看云端数据"按钮
2. 链接将复制到剪贴板
3. 在浏览器中打开 OneNET 控制台
4. 进入设备详情页查看数据

### 4.3 数据上报时机

- **手动上报**：点击上传按钮
- **自动上报**（可选）：在接收到蓝牙数据后自动上报

---

## 五、常见问题

### Q1: 上传失败，提示 Token 错误

**原因**：Token 过期或配置错误

**解决**：
1. 检查 `config/onenet.js` 中的 Token 是否正确
2. 重新生成 Token（确保 et 时间戳是未来时间）
3. 如果使用长期 Token（100年），确保生成时参数正确

### Q2: 上传成功但在平台看不到数据

**原因**：物模型未配置或数据格式不匹配

**解决**：
1. 检查物模型是否配置了对应的属性（heart_rate, blood_oxygen 等）
2. 检查数据格式是否正确（OneJSON 格式）
3. 在设备详情页的"数据流"或"物模型数据"中查看

### Q3: 如何查看原始数据

**方法**：
1. 登录 OneNET 控制台
2. 进入产品详情
3. 点击"设备管理"
4. 找到设备，点击"数据流"
5. 查看原始数据点

### Q4: Token 有效期多久

**回答**：
- 生成 Token 时可以指定有效期
- 建议生成长期 Token（如100年），避免频繁更换
- Token 过期后需要重新生成并更新配置

### Q5: 支持批量上传吗

**回答**：支持！代码已实现批量上传功能：
- 自动将多条数据打包上传
- 支持历史数据批量上报
- 减少网络请求次数

---

## 📞 技术支持

- OneNET 官方文档：https://open.iot.10086.cn/doc/iot_platform/book/introduce/index.html
- OneNET 控制台：https://open.iot.10086.cn/studio/
- API 调试工具：https://open.iot.10086.cn/console/monitor/apiDebug

---

## ✅ 检查清单

完成接入前，请确认：

- [ ] 已注册 OneNET 账号并完成实名认证
- [ ] 已创建产品和设备
- [ ] 已记录 ProductID、DeviceName、DeviceSecret
- [ ] 已生成 Token
- [ ] 已配置 `config/onenet.js` 文件
- [ ] 已配置物模型（可选但推荐）
- [ ] 已测试数据上传功能

完成以上步骤后，你的历史数据就可以成功存储到 OneNET 云平台了！
